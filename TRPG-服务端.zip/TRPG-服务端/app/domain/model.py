"""TRPG aggregate roots / entities / value objects (MIT).

Pure in-memory state shaped by projector.reduce(); persistence lives in
app.store (event_store / snapshot). Python 3.12 compatible.
"""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Table(Strict):
    table_id: str
    campaign_id: str
    ruleset: str
    config: dict[str, Any] = Field(default_factory=dict)


class TurnWindowState(Strict):
    campaign_id: str
    turn_no: int = 0
    state: str = "IDLE"
    submitted: dict[str, dict[str, Any]] = Field(default_factory=dict)
    order: list[str] = Field(default_factory=list)
    cursor: str = ""
    countdown_end_ts: str = ""


class ApprovalItem(Strict):
    proposal_id: str
    campaign_id: str
    text: str
    intention: str | None = None
    source: str = "agent"
    status: str = "pending"  # pending|approved|edited|rejected


class SessionState(Strict):
    campaign_id: str
    table_id: str = ""
    world_intro: str = ""
    characters: dict[str, dict[str, Any]] = Field(default_factory=dict)
    finalized_cards: list[str] = Field(default_factory=list)
    turn: TurnWindowState | None = None
    checks: list[dict[str, Any]] = Field(default_factory=list)
    narrations: dict[str, dict[str, Any]] = Field(default_factory=dict)
    approvals: dict[str, ApprovalItem] = Field(default_factory=dict)
    infos: dict[str, dict[str, Any]] = Field(default_factory=dict)
    clues: dict[str, dict[str, Any]] = Field(default_factory=dict)
    branches: list[dict[str, Any]] = Field(default_factory=list)
    transcripts: list[dict[str, Any]] = Field(default_factory=list)
    transcript_ready: bool = False
    summaries: list[dict[str, Any]] = Field(default_factory=list)
    roles: dict[str, dict[str, Any]] = Field(default_factory=dict)
    votes: list[dict[str, Any]] = Field(default_factory=list)
    truth: dict[str, Any] = Field(default_factory=dict)
    npc_lines: dict[str, str] = Field(default_factory=dict)
    maps: dict[str, dict[str, Any]] = Field(default_factory=dict)
    act_no: int = 0
    archived: bool = False
    last_seq: int = -1

    def ensure_turn(self, campaign_id: str) -> TurnWindowState:
        if self.turn is None:
            self.turn = TurnWindowState(campaign_id=campaign_id)
        return self.turn


def new_session(campaign_id: str) -> SessionState:
    return SessionState(campaign_id=campaign_id)
