"""TRPG domain subpackage (MIT)."""
