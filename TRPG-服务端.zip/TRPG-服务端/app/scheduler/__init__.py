"""TRPG scheduler subpackage (MIT)."""
