"""TRPG web subpackage (MIT)."""
