"""R4/R5/R15/R16/R20 —— GM 单窗口总览与控制面（**全部 additive**，独立 APIRouter）。

挂载方式与 `app/web/pipeline_api.py`、`app/web/rules_api.py`、`app/npc/routes.py` 同源：
只在 `app/main.py` 加 import + include_router 两行，不改任何既有模块。

冻结件遵守：
  * 不新增 WS 帧（R16 交汇提示复用既有 `BRANCH_TAKEN`）。
  * 不新增事件类型（`app/domain/events.py` EVENT_TYPES 未改）。
  * R15 落图**复用既有 `MAP_UPDATED` + 既有 `map_command`**，不新增 map op。
  * R4 复用既有 `access._advice_core`（同一 gateway/降级链），**不另造第二套建议机制**；
    差别仅在于 scene/events 由**服务端装配权威状态**，而非调用方传入。
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException

from app.agent import roles as roles_mod
from app.store.event_store import EventStore
from app.store.projector import project
from app.web.access import ADVICE_TYPES, _advice_core, _require_kp_end
from app.web.rest import DEFAULT_DB, MapCommand, map_command

router = APIRouter()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


async def _state(campaign: str):
    store = EventStore(DEFAULT_DB)
    await store.init()
    events = await store.replay(campaign)
    return project(events, campaign), events


# ---------------------------------------------------------------- 地图折叠 (R5 ①/R15)

def _fold_map(maps: dict[str, Any]) -> dict[str, Any]:
    """把 `state.maps[map_id].ops` 折叠成 {token: room}。

    投影器只记录 ops 日志（`{op,target,delta}`），不折叠空间关系；此处按 ops 顺序重放。
    delta 的房间字段名做**防御性**兼容（room / room_id / to），并原样回报所用字段名，
    以便调用方核验"确实读了真实状态"而非编造。
    """
    out: dict[str, Any] = {}
    for map_id, m in (maps or {}).items():
        tokens: dict[str, str] = {}
        room_keys: set[str] = set()
        fog: list[str] = []
        for op in (m or {}).get("ops", []):
            o, target, delta = op.get("op"), str(op.get("target", "")), op.get("delta") or {}
            room = None
            for k in ("room", "room_id", "to", "to_room"):
                if isinstance(delta.get(k), str) and delta.get(k):
                    room = delta[k]
                    room_keys.add(k)
                    break
            if o in ("move", "add_token") and target and room:
                tokens[target] = room
            elif o == "set_fog" and target:
                if target not in fog:
                    fog.append(target)
        out[map_id] = {"map_id": map_id, "token_rooms": tokens, "fog": fog,
                       "op_count": len((m or {}).get("ops", [])),
                       "room_field_keys": sorted(room_keys)}
    return out


# ---------------------------------------------------------------- R5 六类信息块

@router.get("/api/campaigns/{campaign}/overview")
async def overview(campaign: str, _: Any = Depends(_require_kp_end)) -> dict[str, Any]:
    """R5：单窗口总览所需的 6 类信息块，一次取齐（GM 端首屏不再拼多个请求）。"""
    st, events = await _state(campaign)
    folded = _fold_map(st.maps)
    first_map = next(iter(folded.values()), {"map_id": "", "token_rooms": {}, "fog": []})
    token_rooms = first_map.get("token_rooms", {})

    # ② 玩家位置/状态
    # 实测：库中**没有任何 campaign 有 CHARACTER_CREATED 事件**，玩家只以地图棋子形式存在。
    # 因此玩家集合取「角色卡 ∪ 地图棋子」的并集 —— 否则 ② 块在真实数据上恒为空。
    chars_all = dict(st.characters or {})
    for tok in token_rooms:
        if tok.startswith("pl_") and tok not in chars_all:
            chars_all[tok] = {}
    players: list[dict[str, Any]] = []
    for pid, ch in chars_all.items():
        ch = ch or {}
        players.append({
            "player_id": pid,
            "name": ch.get("name") or ch.get("char_name") or pid,
            "occupation": ch.get("occupation") or ch.get("job") or "",
            "hp": ch.get("hp"), "mp": ch.get("mp"), "san": ch.get("san"),
            "status": ch.get("status") or ("已定卡" if pid in (st.finalized_cards or []) else "未定卡"),
            "room_id": token_rooms.get(pid, ""),
            "source": "character_card" if (st.characters or {}).get(pid) else "map_token",
        })

    # ③ 当前回合与已提交行动
    turn = None
    if st.turn is not None:
        t = st.turn
        turn = {"turn_no": t.turn_no, "state": t.state,
                "countdown_end_ts": t.countdown_end_ts,
                "submitted": [{"player_id": k, "intent": (v or {}).get("intent", "")}
                              for k, v in (t.submitted or {}).items()],
                "submitted_count": len(t.submitted or {}), "order": list(t.order or [])}

    # ④ 待审队列
    pending = [{"proposal_id": a.proposal_id, "text": a.text, "intention": a.intention,
                "source": a.source, "status": a.status}
               for a in (st.approvals or {}).values() if a.status == "pending"]

    # ⑤ 事件/线索
    recent_events = [{"seq": e.seq, "type": e.type, "ts": e.ts} for e in events[-20:]]
    clues = [{"clue_id": k, **(v or {})} for k, v in (st.clues or {}).items()]
    infos = [{"info_id": k, **(v or {})} for k, v in (st.infos or {}).items()]

    # ⑥ NPC 状态
    npcs = [{"npc_id": k, "line": v} for k, v in (st.npc_lines or {}).items()]

    return {
        "campaign_id": campaign, "generated_ts": _now(),
        "blocks": {
            "map": {"map_id": first_map.get("map_id", ""),
                    "rooms": sorted(set(token_rooms.values())),
                    "tokens": token_rooms, "fog": first_map.get("fog", []),
                    "maps_count": len(folded)},
            "players": players,
            "turn": turn,
            "approvals": {"pending_count": len(pending), "pending": pending},
            "events": {"recent": recent_events, "clues": clues, "infos": infos,
                       "tip": (events[-1].seq if events else -1)},
            "npcs": {"count": len(npcs), "npcs": npcs},
        },
        "counts": {"players": len(players), "pending": len(pending),
                   "clues": len(clues), "npcs": len(npcs), "events": len(events)},
    }


# ---------------------------------------------------------------- R16 并行线程

@router.get("/api/campaigns/{campaign}/threads")
async def threads(campaign: str, _: Any = Depends(_require_kp_end)) -> dict[str, Any]:
    """R16：并行叙事线程并列视图 + 交汇提示。

    数据源是既有投影 `state.branches`（由冻结的 BRANCH_TAKEN/BRANCH_OVERRIDDEN 折叠而来）。
    交汇判定：两条线程的 `node_id` 相同（同一节点被多次进入），或其中之一是另一条的
    前驱/后继链上的节点（用已有 branch 记录的出现顺序做保守判定）。
    **不新增 WS 帧** —— 交汇提示作为本接口的读侧结论返回。
    """
    st, _ = await _state(campaign)
    branches = [b or {} for b in (st.branches or [])]
    by_node: dict[str, list[int]] = {}
    for i, b in enumerate(branches):
        nid = str(b.get("node_id") or b.get("label") or f"b{i}")
        by_node.setdefault(nid, []).append(i)

    lines: list[dict[str, Any]] = []
    for nid, idxs in by_node.items():
        b0 = branches[idxs[0]]
        lines.append({"node_id": nid, "label": b0.get("label", nid),
                      "visits": len(idxs), "seqs": [branches[i].get("seq") for i in idxs],
                      "consequences": b0.get("consequences", [])})

    convergence: list[dict[str, Any]] = []
    for nid, idxs in by_node.items():
        if len(idxs) > 1:
            convergence.append({"node_id": nid, "kind": "same_node",
                                "visits": len(idxs),
                                "message": f"线程在节点「{nid}」交汇（{len(idxs)} 次进入）"})
    # 保守的前驱/后继交汇：后一节点被较早线程走到过
    for i in range(1, len(branches)):
        cur = str(branches[i].get("node_id") or "")
        prev = str(branches[i - 1].get("node_id") or "")
        if cur and cur in by_node and len(by_node[cur]) > 1 and cur != prev:
            if not any(c["node_id"] == cur for c in convergence):
                convergence.append({"node_id": cur, "kind": "shared_successor",
                                    "message": f"线程汇入后继节点「{cur}」"})

    return {"campaign_id": campaign, "generated_ts": _now(),
            "parallel_count": len(lines), "lines": lines,
            "convergence": convergence,
            "has_convergence": bool(convergence),
            "convergence_hint": (convergence[0]["message"] if convergence
                                 else "暂无交汇：各线程仍在独立推进")}


# ---------------------------------------------------------------- R15 一键分配

def _suggest(st: Any, folded: dict[str, Any]) -> list[dict[str, Any]]:
    """确定性分配建议（无随机、可复现）。

    依据**真实状态**：①已折叠的 token→room；②角色卡（谁还没落位）；③NPC 所在房间。
    每条建议都带 `reason` 与 `evidence`（引用了哪些真实字段/值），便于核验非模板化。
    """
    first = next(iter(folded.values()), {"map_id": "", "token_rooms": {}})
    map_id, token_rooms = first.get("map_id", ""), dict(first.get("token_rooms", {}))
    rooms = sorted(set(token_rooms.values()))
    chars = list((st.characters or {}).keys())
    for tok in token_rooms:  # 玩家也可能只以棋子形式存在（见 overview ② 的说明）
        if tok.startswith("pl_") and tok not in chars:
            chars.append(tok)
    npc_rooms = {k: token_rooms.get(k) for k in (st.npc_lines or {}) if token_rooms.get(k)}
    occupancy: dict[str, int] = {}
    for r in token_rooms.values():
        occupancy[r] = occupancy.get(r, 0) + 1

    out: list[dict[str, Any]] = []
    for pid in chars:
        cur = token_rooms.get(pid)
        if cur is None:
            # 未落位：放进人最多的房间（保持队伍聚集），否则第一个房间
            target = max(occupancy, key=lambda r: occupancy[r]) if occupancy else (rooms[0] if rooms else "")
            out.append({"player_id": pid, "from_room": None, "to_room": target,
                        "kind": "place",
                        "reason": f"角色 {pid} 尚未在地图上落位；建议放入当前人数最多的房间以保持队伍聚集",
                        "evidence": {"occupancy": dict(occupancy), "rooms": rooms,
                                     "source": "state.maps[*].ops 折叠 + state.characters"}})
        elif npc_rooms and cur not in npc_rooms.values():
            # 有人物在别的房间而 NPC 房无人：建议前往最近的 NPC 房
            target = next((r for r in npc_rooms.values() if occupancy.get(r, 0) == 0), None)
            if target:
                out.append({"player_id": pid, "from_room": cur, "to_room": target,
                            "kind": "escort",
                            "reason": f"NPC 所在房间「{target}」当前无玩家在场；建议 {pid} 前往以推进互动",
                            "evidence": {"npc_rooms": npc_rooms, "occupancy": dict(occupancy),
                                         "source": "state.npc_lines ∩ 折叠后的 token→room"}})
    if not out:
        out.append({"player_id": "", "from_room": None, "to_room": "",
                    "kind": "noop",
                    "reason": "当前状态下无需调整：所有角色均已落位且 NPC 房间已有玩家",
                    "evidence": {"occupancy": dict(occupancy), "npc_rooms": npc_rooms}})
    return out


@router.get("/api/campaigns/{campaign}/allocation/suggest")
async def allocation_suggest(campaign: str, _: Any = Depends(_require_kp_end)) -> dict[str, Any]:
    """R15：一键分配建议（读侧）。落图走 `/allocation/apply`。"""
    st, _ = await _state(campaign)
    folded = _fold_map(st.maps)
    sug = _suggest(st, folded)
    first = next(iter(folded.values()), {"map_id": ""})
    return {"campaign_id": campaign, "map_id": first.get("map_id", ""),
            "suggestions": sug, "count": len(sug), "generated_ts": _now()}


@router.post("/api/campaigns/{campaign}/allocation/apply", status_code=201)
async def allocation_apply(campaign: str, body: dict[str, Any] = Body(default={}),
                           _: Any = Depends(_require_kp_end)) -> dict[str, Any]:
    """R15：一键应用 —— **复用既有 `map_command`（既有 MAP_OPS 的 move）**，不新增 op。"""
    st, _ = await _state(campaign)
    folded = _fold_map(st.maps)
    map_id = body.get("map_id") or next(iter(folded.values()), {}).get("map_id", "")
    if not map_id:
        raise HTTPException(status_code=422, detail="no map for campaign")
    items = body.get("suggestions")
    if not isinstance(items, list) or not items:
        items = [s for s in _suggest(st, folded) if s.get("kind") != "noop"]
    applied: list[dict[str, Any]] = []
    for s in items:
        pid, room = str(s.get("player_id") or ""), str(s.get("to_room") or "")
        if not pid or not room:
            continue
        res = await map_command(campaign, MapCommand(
            map_id=map_id, op="move", target=pid, delta={"room": room}, actor="kp"))
        applied.append({"player_id": pid, "to_room": room, "seq": res.get("seq")})
    return {"campaign_id": campaign, "map_id": map_id,
            "applied_count": len(applied), "applied": applied, "ts": _now()}


# ---------------------------------------------------------------- R20 角色启停

@router.get("/api/campaigns/{campaign}/agents/roles")
async def agents_roles(campaign: str, _: Any = Depends(_require_kp_end)) -> dict[str, Any]:
    """R20：≥4 个职责角色 + 各自启停 + 健康/降级态（UI 直接渲染）。"""
    return roles_mod.role_summary(campaign)


@router.post("/api/campaigns/{campaign}/agents/roles/{role_id}")
async def agents_role_set(campaign: str, role_id: str,
                          body: dict[str, Any] = Body(default={}),
                          _: Any = Depends(_require_kp_end)) -> dict[str, Any]:
    """R20：单独启用/停用某角色（其余角色不受影响）。"""
    if role_id not in roles_mod.ROLE_IDS:
        raise HTTPException(status_code=404, detail="unknown role %r" % role_id)
    enabled = bool(body.get("enabled", True))
    changed = roles_mod.set_enabled(campaign, role_id, enabled)
    return {"campaign_id": campaign, **changed,
            "summary": roles_mod.role_summary(campaign)}


@router.post("/api/campaigns/{campaign}/agents/roles/{role_id}/probe")
async def agents_role_probe(campaign: str, role_id: str,
                            body: dict[str, Any] = Body(default={}),
                            _: Any = Depends(_require_kp_end)) -> dict[str, Any]:
    """R20 验收探针：让指定角色"工作"并可选注入失败，用于证明
    ①单角色失败不影响其他角色 ②降级对 GM 可见。**不落事件、不改业务状态。**"""
    if role_id not in roles_mod.ROLE_IDS:
        raise HTTPException(status_code=404, detail="unknown role %r" % role_id)
    fail = bool(body.get("fail", False))

    def _work() -> str:
        if fail:
            raise RuntimeError("probe: injected failure")
        return "ok"

    result, degraded = roles_mod.run_role(campaign, role_id, _work, fallback="unavailable")
    return {"campaign_id": campaign, "role_id": role_id, "result": result,
            "degraded": degraded, "summary": roles_mod.role_summary(campaign)}


# ---------------------------------------------------------------- R4 grounding

@router.post("/api/campaigns/{campaign}/advice/grounded")
async def advice_grounded(campaign: str, body: dict[str, Any] = Body(default={}),
                          _: Any = Depends(_require_kp_end)) -> dict[str, Any]:
    """R4：建议必须引用**真实**场景/玩家/NPC 状态。

    与既有 `POST /access/advice` 的区别**仅**在于：scene 与 events **由服务端装配权威状态**，
    调用方不再（也无法）自行传入 —— 从而杜绝"退化为通用模板"。
    复用同一个 `_advice_core`（同一 gateway、同一降级链、同一幂等键）。
    """
    rtype = str(body.get("request_type") or "ruling")
    if rtype not in ADVICE_TYPES:
        raise HTTPException(status_code=422, detail="bad request_type %r" % rtype)
    st, events = await _state(campaign)
    folded = _fold_map(st.maps)
    first = next(iter(folded.values()), {"map_id": "", "token_rooms": {}})
    token_rooms = first.get("token_rooms", {})

    # —— 服务端装配权威上下文 ——
    chars = st.characters or {}
    scene_parts = [f"地图={first.get('map_id','') or '未载入'}"]
    for pid, ch in list(chars.items())[:8]:
        nm = (ch or {}).get("name") or pid
        scene_parts.append(f"{nm}@{token_rooms.get(pid,'未落位')}")
    if st.npc_lines:
        scene_parts.append("NPC：" + "；".join(f"{k}→{str(v)[:40]}" for k, v in list(st.npc_lines.items())[:4]))
    if st.turn is not None:
        scene_parts.append(f"回合#{st.turn.turn_no}/{st.turn.state}")
    scene = " | ".join(scene_parts)

    grounded_events = [f"{e.type}#{e.seq}" for e in events[-20:]]
    hint = str(body.get("hint") or "")

    res = _advice_core(campaign, rtype, scene, grounded_events, hint, str(body.get("req_id") or ""))
    return {"campaign_id": campaign, **res,
            "grounding": {"scene_assembled_by": "server",
                          "scene": scene,
                          "player_count": len(chars),
                          "npc_count": len(st.npc_lines or {}),
                          "event_refs": grounded_events,
                          "token_rooms": token_rooms},
            "ts": _now()}
