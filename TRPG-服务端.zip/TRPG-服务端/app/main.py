"""TRPG single-process assembly (MIT). W-E T12: /api + static + WS + /mcp.
EX-2 D3/D4: /ws 握手 token 校验 + PING 心跳后台任务 (additive 安全加固).
"""
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect

from app.config import get_version
from app.mcp.server import router as mcp_router
from app.web.access import (install_access_error_handler,
                            load_persisted_tables, router as access_router,
                            token_end_name, token_matches_any_enabled_end)
from app.store.event_store import EventStore
from app.web import ws_bridge
from app.web.identity import router as identity_router
from app.web.pipeline_api import router as pipeline_router  # T7 (additive)
from app.web.rest import router as rest_router
# R4/R5/R15/R16/R20 (additive): GM 单窗口总览 + 分配建议 + 并行线程 + 角色启停 + grounded 建议.
from app.web.overview_api import router as overview_router
# R23 (additive): rulepack binding + per-ruleset resolution surface.
from app.web.rules_api import router as rules_router
from app.npc.routes import router as npc_router  # R28-R31 (additive)
from app.web.rest_repo import (install_repo_error_handler,
                               install_repo_path_guard, router as repo_router)
from app.web.static import mount_static
from app.web.ws import Connection, Hub, heartbeat_loop

hub = Hub()

_hb_task: asyncio.Task | None = None


@asynccontextmanager
async def _lifespan(_app: FastAPI):
    """EX-2 D4: 启动即拉起 PING 心跳后台任务, 服务关闭时取消 (不泄漏任务).

    T2 (additive, ENDPOINT-SPEC-NEW §8): 同时把「事件落库 -> WS 广播」的发布
    回调挂到 EventStore 的单一收口上。未挂载时 on_append 为 None, 行为与改造前
    完全一致 (既有测试/纯 store 脚本不受影响)。
    """
    global _hb_task
    EventStore.on_append = ws_bridge.publish_events
    # T2: 载入持久化的 table 注册表 —— 否则服务重启后所有已开桌的
    # table<->campaign 映射丢失, /access/table/resolve 恒 exists:false (F2 失效)。
    load_persisted_tables()
    _hb_task = asyncio.create_task(heartbeat_loop(hub), name="ws-heartbeat")
    try:
        yield
    finally:
        EventStore.on_append = None
        if _hb_task is not None:
            _hb_task.cancel()
            try:
                await _hb_task
            except asyncio.CancelledError:
                pass
            _hb_task = None


app = FastAPI(title="trpg", version=get_version(), lifespan=_lifespan)

app.include_router(rest_router)
app.include_router(rules_router)  # R23: /api/rules/*
app.include_router(npc_router)  # R28-R31 (additive): NPC 自主性控制面
app.include_router(mcp_router)
app.include_router(access_router)
# T7 (additive): 统一审批总线闭环路由 (R10/R11/R17/R18/R19)
app.include_router(pipeline_router)
app.include_router(overview_router)  # R4/R5/R15/R16/R20 (additive)
# SPEC-SERVER-IDENTITY v1.0 (additive): 部署身份端点 GET /__trpg_server__。
# 与 /api/health（只表示「活着」）分离；无鉴权，只暴露部署身份，不含密钥/令牌。
app.include_router(identity_router)
# R22/R1/R2/R13/R3 (additive): 模组仓库 + 规则仓库 REST, 路径穿越守卫,
# RepoError -> {error_code,message,http_status,detail} 映射。
app.include_router(repo_router)
install_repo_path_guard(app)
install_repo_error_handler(app)
install_access_error_handler(app)
mount_static(app)


@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket) -> None:
    params = dict(ws.query_params)
    table_id = params.get("table", "")
    viewer_id = params.get("viewer", "")
    role = params.get("role", "pl")
    try:
        last_seq = int(params.get("last_seq", "-1"))
    except ValueError:
        last_seq = -1
    if not table_id or not viewer_id or role not in ("kp", "pl", "spectator"):
        await ws.close(code=4400)
        return
    # EX-2 D3: token 校验 (?token= 或 Authorization: Bearer; 与 /access 同源,
    # 任一启用端 token 放行). 缺失/不匹配 -> 4400 关闭 (沿用既有参数错误码).
    token = params.get("token", "") or ""
    if not token:
        authz = ws.headers.get("authorization", "")
        if str(authz).lower().startswith("bearer "):
            token = str(authz)[7:].strip()
    if not token_matches_any_enabled_end(token):
        await ws.close(code=4400)
        return
    # R9 (additive): 角色由 **token 所属端** 决定 —— 非 KP 端 token 不得自封 kp。
    # 既有实现信任 ?role=kp，玩家只要改查询串即可拿到 KP 帧（R9 第三条外泄路径）。
    if token_end_name(token) != "webapp" and role == "kp":
        role = "pl"
    await ws.accept()

    async def send(payload: dict) -> None:
        await ws.send_json(payload)

    conn = Connection(table_id=table_id, viewer_id=viewer_id, role=role, send=send)
    missed = await hub.connect(conn, last_seq)
    for frame in missed:
        await ws.send_json(frame)
    try:
        while True:
            raw = await ws.receive_json()
            if isinstance(raw, dict) and raw.get("kind") == "PING":
                continue  # client pings need no reply; server PING comes from hub
            ack = await hub.handle_up(table_id, viewer_id, raw if isinstance(raw, dict) else {})
            await ws.send_json(ack)
    except WebSocketDisconnect:
        await hub.disconnect(table_id, viewer_id)


@app.get("/")
def root() -> dict:
    return {"service": "trpg", "health": "/api/health"}
