"""TRPG store subpackage (MIT)."""
