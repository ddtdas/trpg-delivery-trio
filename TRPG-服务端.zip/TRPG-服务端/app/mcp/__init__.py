"""TRPG MCP package (MIT)."""
