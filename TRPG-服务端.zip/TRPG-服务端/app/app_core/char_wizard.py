"""TRPG character-creation wizard state machine (MIT).

Multi-step fill, backward moves (CARD_REVERTED), validation via the shared
hard gate, and CARD_FINALIZED/CARD_REVERTED/CHARACTER_CREATED events into
the store. Python 3.12 compatible.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone

from app.domain.character import REQUIRED_ATTRS, CharacterCard, validate_card
from app.domain.events import make_event
from app.store.event_store import EventStore

STEPS: tuple[str, ...] = ("basics", "attrs", "skills", "background", "review", "done")

STEP_INDEX: dict[str, int] = {name: i for i, name in enumerate(STEPS)}


class WizardError(ValueError):
    """Raised on illegal wizard transitions or bad step data."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class WizardSession:
    card_id: str
    player_id: str
    ruleset: str = "coc7"
    step: str = "basics"
    name: str = ""
    attrs: dict[str, int] = field(default_factory=dict)
    skills: dict[str, int] = field(default_factory=dict)
    background: str = ""
    secret_ref: str | None = None
    history: list[str] = field(default_factory=list)

    def to_card(self) -> CharacterCard:
        return CharacterCard(
            card_id=self.card_id,
            player_id=self.player_id,
            ruleset=self.ruleset,
            name=self.name,
            attrs=dict(self.attrs),
            skills=dict(self.skills),
            background=self.background,
            secret_ref=self.secret_ref,
        )


class CharWizard:
    """In-memory sessions; every mutation emits store events for audit."""

    def __init__(self, store: EventStore, campaign_id: str, actor: str = "kp") -> None:
        self.store = store
        self.campaign_id = campaign_id
        self.actor = actor
        self.sessions: dict[str, WizardSession] = {}

    def start(self, player_id: str, ruleset: str = "coc7",
              card_id: str | None = None) -> WizardSession:
        cid = card_id or ("card_" + uuid.uuid4().hex[:8])
        if cid in self.sessions:
            raise WizardError("card already in progress: %s" % cid)
        sess = WizardSession(card_id=cid, player_id=player_id, ruleset=ruleset)
        sess.history.append("basics")
        self.sessions[cid] = sess
        return sess

    def get(self, card_id: str) -> WizardSession:
        try:
            return self.sessions[card_id]
        except KeyError:
            raise WizardError("unknown card: %s" % card_id) from None

    def fill(self, card_id: str, step: str, data: dict) -> WizardSession:
        sess = self.get(card_id)
        if step not in STEP_INDEX:
            raise WizardError("unknown step: %r" % step)
        if step == "done":
            raise WizardError("use finalize() to reach done")
        if not isinstance(data, dict):
            raise WizardError("step data must be an object")
        if step == "basics":
            name = str(data.get("name", ""))
            if not name.strip():
                raise WizardError("basics.name: required")
            sess.name = name.strip()
        elif step == "attrs":
            attrs = data.get("attrs", data)
            if not isinstance(attrs, dict):
                raise WizardError("attrs: must be an object")
            for attr in REQUIRED_ATTRS:
                if attr not in attrs:
                    raise WizardError("attrs.%s: missing" % attr)
                try:
                    v = int(attrs[attr])
                except (TypeError, ValueError):
                    raise WizardError("attrs.%s: not an int" % attr) from None
                if not 1 <= v <= 100:
                    raise WizardError("attrs.%s: out of range 1..100" % attr)
            sess.attrs = {k: int(attrs[k]) for k in REQUIRED_ATTRS}
        elif step == "skills":
            skills = data.get("skills", data)
            if not isinstance(skills, dict):
                raise WizardError("skills: must be an object")
            for skill, v in skills.items():
                try:
                    iv = int(v)
                except (TypeError, ValueError):
                    raise WizardError("skills.%s: not an int" % skill) from None
                if not 0 <= iv <= 100:
                    raise WizardError("skills.%s: out of range 0..100" % skill)
            sess.skills = {k: int(v) for k, v in skills.items()}
        elif step == "background":
            sess.background = str(data.get("background", ""))
            if data.get("secret_ref") is not None:
                sess.secret_ref = str(data["secret_ref"])
        elif step == "review":
            pass  # review carries no new data; gate lives in finalize()
        # Forward-only step pointer, but any earlier step may be re-filled.
        if STEP_INDEX[step] > STEP_INDEX[sess.step]:
            sess.step = step
        if step not in sess.history:
            sess.history.append(step)
        return sess

    def back(self, card_id: str, to_step: str) -> WizardSession:
        """Move the pointer back; the move itself is audited on finalize path."""
        sess = self.get(card_id)
        if to_step not in STEP_INDEX:
            raise WizardError("unknown step: %r" % to_step)
        if STEP_INDEX[to_step] >= STEP_INDEX[sess.step]:
            raise WizardError("back() must move to an earlier step")
        sess.step = to_step
        sess.history.append("back:%s" % to_step)
        return sess

    async def revert(self, card_id: str, to_step: str, reason: str) -> WizardSession:
        sess = self.back(card_id, to_step)
        from_step = sess.history[-2] if len(sess.history) >= 2 else sess.step
        ev = make_event(
            seq=0, campaign_id=self.campaign_id, type="CARD_REVERTED",
            payload={"card_id": card_id, "from_step": from_step,
                     "to_step": to_step, "reason": reason},
            actor=self.actor, ts=_now())
        await self.store.append(self.campaign_id, [ev])
        return sess

    async def finalize(self, card_id: str) -> CharacterCard:
        sess = self.get(card_id)
        card = sess.to_card()
        report = validate_card(card)
        if not report.ok:
            raise WizardError("card invalid: %s" % "; ".join(report.errors))
        created = make_event(
            seq=0, campaign_id=self.campaign_id, type="CHARACTER_CREATED",
            payload={"card_id": card.card_id, "player_id": card.player_id,
                     "ruleset": card.ruleset,
                     "card": card.model_dump(mode="json")},
            actor=self.actor, ts=_now())
        finalized = make_event(
            seq=0, campaign_id=self.campaign_id, type="CARD_FINALIZED",
            payload={"card_id": card.card_id, "validation_report_ref": "vr:%s" % card.card_id},
            actor=self.actor, ts=_now(), approved_by=self.actor)
        await self.store.append(self.campaign_id, [created, finalized])
        sess.step = "done"
        sess.history.append("done")
        return card
