/* TRPG 跑团玩家端（PC / 移动浏览器版）—— 零构建、零依赖、无 CDN。
   实现依据: docs/CROSS-END-CONTRACT.md v1.1
     §1 端点与统一包裹 / §2 设计令牌 / §3 WS（可选增强通道）/ §4 F1-F10 / §5 固定文案 / §7 约束与风险
   与小程序端功能集合、文案、设计令牌完全一致。 */
(function () {
  'use strict';

  /* 构建标记（便于验收确认加载的是哪一版）：契约 v1.1 实现 */
  window.__TRPG_PLAYER_BUILD = 'web-player/v1.1.0';

  /* ---------- 固定文案（与 strings.json 逐字相同；契约 §5.1 / §5.2） ---------- */
  var S = {
    'title': 'TRPG 跑团玩家端',
    'nav.setup': '连接设置',
    'nav.table': '桌面',
    'nav.voice': '语音',
    'btn.test': '测试连接',
    'btn.resolve': '解析连接码',
    'btn.join': '加入跑团',
    'btn.leave': '离开桌面',
    'btn.submit': '提交行动',
    'btn.recStart': '开始录音',
    'btn.recStop': '停止并上传',
    'btn.query': '查询',
    'ph.server': '服务器地址，如 http://192.168.10.110:9210',
    'ph.code': '连接码，如 TABLE-XXXX',
    'ph.playerId': '玩家 ID，如 pl-001',
    'ph.playerName': '昵称',
    'ph.action': '描述你要做什么…（必填）',
    'ph.intent': '意图摘要（选填）',
    'ph.deviceId': '设备 ID',
    'st.connecting': '连接中…',
    'st.connected': '已连接',
    'st.reconnecting': '重连中…',
    'st.closed': '已断开',
    'st.collecting': '行动收集中',
    'st.notCollecting': '当前不在行动收集阶段，请等待主持人开启回合',
    'st.submitted': '已提交，等待主持人结算',
    'st.duplicate': '重复提交已忽略',
    'st.emptyAction': '行动描述不能为空',
    'st.noTurn': '尚未开启回合',
    'st.noDevice': '无该设备记录',
    'err.net': '网络连接失败，请检查服务器地址与网络',
    'err.auth': '身份验证失败：token 无效或未启用该端',
    'err.notFound': '连接码不存在',
    'err.server': '服务端异常',
    'sec.role': '我的状态',
    'sec.turn': '回合',
    'sec.action': '行动',
    'sec.events': '事件流',
    'sec.voice': '语音',
    'sec.device': '录音设备',
    'ev.ACTION_SUBMITTED': '行动提交',
    'ev.TURN_STARTED': '回合开始',
    'ev.TURN_CLOSED': '回合结束',
    'ev.CHECK_RESOLVED': '检定',
    'ev.NARRATION_PROPOSED': '旁白待审',
    'ev.NARRATION_APPROVED': '旁白',
    'ev.NARRATION_EDITED': '旁白（已修订）',
    'ev.NARRATION_REJECTED': '旁白（未通过）',
    'ev.INFO_REVEALED': '公开信息',
    'ev.CLUE_GRANTED': '线索',
    'ev.BRANCH_TAKEN': '分支',
    'ev.BRANCH_OVERRIDDEN': '分支（已覆盖）',
    'ev.TRANSCRIPT_APPENDED': '语音转写',
    'ev.TRANSCRIPT_READY': '语音转写完成',
    'ev.ROLE_ASSIGNED': '角色分配',
    'ev.EVIDENCE_DEALT': '证据发放',
    'ev.VOTE_CAST': '投票',
    'ev.TRUTH_REVEALED': '真相揭示',
    'ev.MAP_UPDATED': '地图更新',
    'ev.SESSION_SUMMARIZED': '场次小结',
    'ev.OTHER': '其他事件',
    'ev.NPC_ACT_PROPOSED': 'NPC 台词待审',
    'ev.NPC_ACT_APPROVED': 'NPC 台词',
    /* 扩展文案（契约 §5 之外，两端逐字相同） */
    'ext.ph.token': '访问 token（mobile 端）',
    'ext.lbl.table': '桌面名称',
    'ext.lbl.campaign': '战役',
    'ext.lbl.version': '服务版本',
    'ext.lbl.ends': '启用端',
    'ext.st.recording': '录音中…',
    'ext.st.recordUnsupported': '当前环境不支持录音（需要 HTTPS/localhost 且设备有可用麦克风）',
    'ext.st.uploadOk': '已上传 {bytes} 字节',
    'ext.st.sttStatus': '转写状态：{status}',
    'ext.st.needServer': '请先填写服务器地址',
    'ext.st.needCode': '请先填写连接码',
    'ext.st.needPlayerId': '请先填写玩家 ID',
    'ext.st.needToken': '请先填写访问 token',
    'ext.st.deviceNone': '无该设备记录',
    'ext.turn.line': '回合 {turn_no} · {state} · 已提交 {submitted}',
    'ext.ev.turn': '回合 {turn_no} · {state}',
    'ext.ev.delta': '状态更新 {delta}',
    'ext.ev.narrationPending': '旁白待审',
    'ext.ev.info': '信息公开 {info_id}',
    'ext.ev.branch': '分支推进 {label}',
    'ext.ev.job': '任务 {job_id} · {status}',
    'ext.ev.directed': '定向消息 {body}',
    /* T15 (additive): R10/R11 地点交互面板文案（与小程序端同键同名，服务端 label 优先） */
    'ix.title': '地点交互',
    'ix.room': '当前房间：{room} · 可交互物 {n} 个',
    'ix.all': '可交互物 {n} 个（未定位到你的房间，显示全部）',
    'ix.none': '当前房间没有可交互物',
    'ix.needJoin': '加入跑团后可进行地点交互',
    'ix.report': '（需报备）',
    'ix.pending': '已上报待主持人',
    'ix.delivered': '主持人已允许',
    'ix.rejected': '主持人暂未允许',
    'ix.mine': '我的交互',
    'ix.pick': '请选择要交互的家具'
  };

  function t(key) { return S[key] || key; }
  function tpl(key, vars) {
    var out = t(key);
    for (var k in vars) {
      if (Object.prototype.hasOwnProperty.call(vars, k)) {
        out = out.split('{' + k + '}').join(String(vars[k]));
      }
    }
    return out;
  }

  /* ---------- 本地存储（F3 / 契约 §3.5） ---------- */
  var LS = {
    playerId: 'trpg.playerId',
    playerName: 'trpg.playerName',
    server: 'trpg.server',
    code: 'trpg.code',
    token: 'trpg.token'
  };
  var LAST_SEQ_PREFIX = 'trpg_last_seq_';   /* 键规则与小程序端相同 */

  function lsGet(k) {
    try { return window.localStorage.getItem(k) || ''; } catch (e) { return ''; }
  }
  function lsSet(k, v) {
    try { window.localStorage.setItem(k, v); } catch (e) { /* 隐私模式降级 */ }
  }

  /* ---------- 全局状态 ---------- */
  var state = {
    server: '', token: '', code: '', tableId: '', campaign: '', tableName: '',
    playerId: '', playerName: '', turn: null, joined: false,
    items: {}, cursor: -1, tip: -1, byType: {}, connState: 'closed', pollFails: 0, infoOk: false,
    ws: null, wsState: 'closed', backoffIdx: 0, lastFrameTs: 0, watchTimer: null,
    pollTimer: null, pushTimer: null, mediaRecorder: null, mediaStream: null, chunks: [],
    lastSubmit: null, submitMsg: '', turnKey: ''
  };

  var $ = function (id) { return document.getElementById(id); };

  function show(el, visible) {
    if (!el) { return; }
    if (visible) { el.classList.remove('hidden'); } else { el.classList.add('hidden'); }
  }
  function setErr(el, msg) {
    if (!el) { return; }
    if (msg) { el.textContent = msg; show(el, true); } else { el.textContent = ''; show(el, false); }
  }
  function hmsFromTs(ts) {
    var d = new Date(ts);
    if (isNaN(d.getTime())) { return String(ts || ''); }
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
  }
  function escapeHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function normalizeServer(v) {
    var s = String(v || '').trim();
    if (!s) { return ''; }
    if (!/^https?:\/\//i.test(s)) { s = 'http://' + s; }
    if (s.charAt(s.length - 1) === '/') { s = s.slice(0, -1); }
    return s;
  }
  function newReqId() {
    try {
      if (window.crypto && typeof window.crypto.randomUUID === 'function') {
        return window.crypto.randomUUID();
      }
    } catch (e) { /* fallthrough */ }
    return 'req-' + Date.now() + '-' + Math.random().toString(16).slice(2, 10);
  }

  /* ---------- 统一响应包裹与错误文案 ---------- */
  function errTextFor(status, json) {
    if (status === 0) { return t('err.net'); }
    if (status === 401 || status === 403) { return t('err.auth'); }
    if (status === 404) { return t('err.notFound'); }
    if (status >= 500) { return t('err.server'); }
    if (json && json.error) { return String(json.error); }
    if (json && json.detail) { return String(json.detail); }
    return t('err.server');
  }

  /* api(): /access/* 与 /api/* 直连；REST 带 Authorization: Bearer <mobile token> */
  function api(path, opts) {
    opts = opts || {};
    var url = normalizeServer(state.server) + path;
    var headers = {};
    if (state.token) { headers['Authorization'] = 'Bearer ' + state.token; }
    var init = { method: opts.method || 'GET', headers: headers };
    if (opts.body !== undefined) {
      if (opts.form) { init.body = opts.body; } else {
        headers['Content-Type'] = 'application/json';
        init.body = JSON.stringify(opts.body);
      }
    }
    return fetch(url, init).then(function (r) {
      return r.text().then(function (text) {
        var json = null;
        try { json = JSON.parse(text); } catch (e) { json = null; }
        return { status: r.status, json: json, text: text };
      });
    }, function () {
      return { status: 0, json: null, text: '' };
    });
  }

  /* ---------- 视图切换 ---------- */
  function showView(name) {
    show($('viewSetup'), name === 'setup');
    show($('viewTable'), name === 'table');
    show($('viewVoice'), name === 'voice');
    $('navSetup').setAttribute('aria-current', name === 'setup' ? 'true' : 'false');
    $('navTable').setAttribute('aria-current', name === 'table' ? 'true' : 'false');
    $('navVoice').setAttribute('aria-current', name === 'voice' ? 'true' : 'false');
  }

  /* ---------- F1 服务器连接 ---------- */
  function testConnection() {
    state.server = normalizeServer($('server').value);
    state.token = String($('token').value || '').trim();
    lsSet(LS.server, state.server);
    lsSet(LS.token, state.token);
    if (!state.server) { setErr($('setupErr'), t('ext.st.needServer')); return Promise.resolve(false); }
    if (!state.token) { setErr($('setupErr'), t('ext.st.needToken')); return Promise.resolve(false); }
    setErr($('setupErr'), '');
    $('setupStatus').textContent = t('st.connecting');
    show($('infoBox'), false);
    return api('/access/info').then(function (res) {
      if (res.status !== 200 || !res.json || !res.json.ok) {
        $('setupStatus').textContent = t('st.closed');
        setErr($('setupErr'), errTextFor(res.status, res.json));
        return false;
      }
      var d = res.json.data || {};
      var ends = d.ends || {};
      $('setupStatus').textContent = t('st.connected');
      var html = '';
      html += '<div class="kv"><span class="k">' + t('ext.lbl.version') + '</span><span>' +
        escapeHtml(String(d.version || '')) + '</span></div>';
      html += '<div class="kv"><span class="k">' + t('ext.lbl.ends') + '</span><span>' +
        escapeHtml(['mobile', 'webapp', 'recorder'].map(function (k) {
          return k + '=' + (ends[k] ? 'on' : 'off');
        }).join(' ')) + '</span></div>';
      $('infoBox').innerHTML = html;
      show($('infoBox'), true);
      state.infoOk = true;
      return true;
    });
  }

  /* ---------- F2 连接码解析 ---------- */
  function resolveCode() {
    state.server = normalizeServer($('server').value);
    state.token = String($('token').value || '').trim();
    state.code = String($('code').value || '').trim();
    lsSet(LS.server, state.server); lsSet(LS.token, state.token); lsSet(LS.code, state.code);
    if (!state.server) { setErr($('setupErr'), t('ext.st.needServer')); return Promise.resolve(false); }
    if (!state.code) { setErr($('setupErr'), t('ext.st.needCode')); return Promise.resolve(false); }
    setErr($('setupErr'), '');
    $('setupStatus').textContent = t('st.connecting');
    return api('/access/table/resolve?code=' + encodeURIComponent(state.code)).then(function (res) {
      if (res.status === 404) {
        $('setupStatus').textContent = t('st.closed');
        setErr($('setupErr'), t('err.notFound'));
        return false;
      }
      if (res.status !== 200 || !res.json || !res.json.ok) {
        $('setupStatus').textContent = t('st.closed');
        setErr($('setupErr'), errTextFor(res.status, res.json));
        return false;
      }
      var d = res.json.data || {};
      if (d.exists === false) {
        $('setupStatus').textContent = t('st.closed');
        setErr($('setupErr'), t('err.notFound'));
        return false;
      }
      state.tableId = String(d.table_id || '');
      state.campaign = String(d.campaign || d.table_id || '');
      state.tableName = String(d.name || d.table_id || '');
      $('setupStatus').textContent = t('st.connected');
      var html = '';
      html += '<div class="kv"><span class="k">' + t('ext.lbl.table') + '</span><span>' +
        escapeHtml(state.tableName) + '</span></div>';
      html += '<div class="kv"><span class="k">' + t('ext.lbl.campaign') + '</span><span>' +
        escapeHtml(state.campaign) + '</span></div>';
      $('infoBox').innerHTML = html;
      show($('infoBox'), true);
      return true;
    });
  }

  /* ---------- F4 加入桌面 ---------- */
  function joinTable() {
    state.playerId = String($('pid').value || '').trim();
    state.playerName = String($('pname').value || '').trim();
    lsSet(LS.playerId, state.playerId);
    lsSet(LS.playerName, state.playerName);
    if (!state.server) { setErr($('setupErr'), t('ext.st.needServer')); return Promise.resolve(); }
    if (!state.code) { setErr($('setupErr'), t('ext.st.needCode')); return Promise.resolve(); }
    if (!state.playerId) { setErr($('setupErr'), t('ext.st.needPlayerId')); return Promise.resolve(); }
    /* 契约 §3.1：连接 WS 之前必须先用 GET /access/info 校验 token 与可达性
       （失败一律不区分 token 错/参数错/路径错，故先用 info 判定） */
    setConnStatus('connecting');
    var p = state.infoOk ? Promise.resolve(true) : testConnection();
    return p.then(function (okInfo) {
      if (!okInfo) { setConnStatus('closed'); return false; }
      return state.tableId ? true : resolveCode();
    }).then(function (okResolve) {
      if (!okResolve) { setConnStatus('closed'); return; }
      state.joined = true;
      state.items = {};
      state.cursor = parseInt(lsGet(LAST_SEQ_PREFIX + state.tableId) || '-1', 10);
      if (isNaN(state.cursor)) { state.cursor = -1; }
      render();
      $('rolePid').textContent = state.playerId;
      $('roleName').textContent = state.playerName || state.playerId;
      $('roleCode').textContent = state.code;
      $('roleTable').textContent = state.tableName || state.tableId;
      $('roleCampaign').textContent = state.campaign;
      showView('table');
      refreshState();
      loadEvents(true);
      startPolling();
      connectWs();
      ixStart();   /* T15 (additive): 进入桌面后加载地点交互面板 */
    });
  }

  function leaveTable() {
    state.joined = false;
    stopPolling();
    closeWs();
    ixStop();   /* T15 (additive): 清空地点交互面板 */
    showView('setup');
  }

  /* ---------- F5 回合状态（2s 轮询兜底） ---------- */
  function refreshState() {
    if (!state.joined || !state.tableId) { return Promise.resolve(); }
    return api('/access/mobile/state?table_id=' + encodeURIComponent(state.tableId))
      .then(function (res) {
        if (res.status === 200 && res.json && res.json.ok) {
          var d = res.json.data || {};
          if (d.campaign) { state.campaign = String(d.campaign); }
          state.turn = d.turn || null;
          state.tip = (typeof d.tip === 'number') ? d.tip : -1;
          state.byType = d.by_type || {};
          state.pollFails = 0;
          setConnStatus('connected');
          renderTurn();
        } else {
          state.pollFails = (state.pollFails || 0) + 1;
          setConnStatus(state.pollFails >= 3 ? 'closed' : 'reconnecting');
          if (res.status === 401 || res.status === 403) { setErr($('submitErr'), t('err.auth')); }
        }
      });
  }
  /* R12：轮询**降级为兜底**（15s 心跳，仅用于 WS 不可用/丢帧时追平）；
     实时性由 WS 推送驱动（onmessage -> pushRefresh -> 立即拉权威数据）。 */
  var POLL_FALLBACK_MS = 15000;
  var PUSH_DEBOUNCE_MS = 60;
  function startPolling() {
    stopPolling();
    state.pollTimer = window.setInterval(function () {
      refreshState();
      loadEvents(false);
    }, POLL_FALLBACK_MS);
  }
  /* WS 帧到达 -> 立即拉一次权威数据（去抖合并同批帧，不等待兜底轮询）。 */
  function pushRefresh() {
    if (state.pushTimer) { return; }
    state.pushTimer = window.setTimeout(function () {
      state.pushTimer = null;
      if (!state.joined) { return; }
      refreshState();
      loadEvents(false);
      ixRefresh();   /* T15 (additive): R10/R11 面板随 WS 帧追平（内部 2.5s/5s 节流） */
    }, PUSH_DEBOUNCE_MS);
  }
  function stopPolling() {
    if (state.pollTimer) { window.clearInterval(state.pollTimer); state.pollTimer = null; }
  }

  function renderTurn() {
    var turn = state.turn;
    if (!turn) {
      $('turnLine').textContent = t('st.noTurn');
      show($('turnChip'), false);
      renderCounts();
      setSubmitEnabled(false);
      return;
    }
    $('turnLine').textContent = tpl('ext.turn.line', {
      turn_no: turn.turn_no, state: turn.state, submitted: turn.submitted
    });
    /* R2: 只把 COLLECTING 当可提交，其余状态原样显示字符串 */
    var collecting = String(turn.state) === 'COLLECTING';
    $('turnChip').textContent = t('st.collecting');
    show($('turnChip'), collecting);
    renderCounts();
    var key = String(turn.turn_no) + '|' + String(turn.state);
    if (key !== state.turnKey) { state.turnKey = key; state.submitMsg = ''; }
    setSubmitEnabled(collecting);
  }

  /* by_type 计数行（与小程序端 table.js::countsText 一致） */
  function renderCounts() {
    if (!$('turnCounts')) { return; }
    var keys = Object.keys(state.byType || {}).sort();
    var parts = [];
    for (var i = 0; i < keys.length; i++) { parts.push(keys[i] + '=' + state.byType[keys[i]]); }
    $('turnCounts').textContent = parts.join(' ');
  }
  function setSubmitEnabled(on) {
    $('btnSubmit').disabled = !on;
    /* 非 COLLECTING 一律显示 st.notCollecting；可提交时显示 st.collecting。
       提交结果（st.submitted / st.duplicate）走 .ok-line，避免被 2s 轮询覆盖。 */
    $('submitStatus').textContent = on ? t('st.collecting') : t('st.notCollecting');
  }

  /* ---------- F6 行动提交 ---------- */
  function submitAction() {
    var text = String($('action').value || '').trim();
    var intent = String($('intent').value || '').trim();
    setErr($('submitErr'), '');
    if (!text) { setErr($('submitErr'), t('st.emptyAction')); return Promise.resolve(); }
    var turn = state.turn;
    if (!turn || String(turn.state) !== 'COLLECTING') {
      setErr($('submitErr'), t('st.notCollecting'));
      return Promise.resolve();
    }
    /* req_id 幂等：同回合同内容 3s 内重复点击视为同一次逻辑提交（防双击），
       复用 req_id -> 服务端只落 1 条事件并返回 duplicate -> 显示 st.duplicate */
    var dedupeKey = turn.turn_no + '|' + text + '|' + intent;
    var reqId;
    if (state.lastSubmit && state.lastSubmit.key === dedupeKey &&
        (Date.now() - state.lastSubmit.ts) < 3000) {
      reqId = state.lastSubmit.reqId;
    } else {
      reqId = newReqId();
    }
    state.lastSubmit = { key: dedupeKey, reqId: reqId, ts: Date.now() };
    var body = {
      campaign: state.campaign,
      turn_no: turn.turn_no,
      player_id: state.playerId,
      action: text,
      intent_summary: intent,
      req_id: reqId
    };
    $('btnSubmit').disabled = true;
    var send = function (attempt) {
      return api('/access/mobile/action', { method: 'POST', body: body }).then(function (res) {
        if (res.status === 0 && attempt === 0) {
          $('submitStatus').textContent = t('st.reconnecting');
          return new Promise(function (resolve) {
            window.setTimeout(function () { resolve(send(1)); }, 800);
          });
        }
        return res;
      });
    };
    return send(0).then(function (res) {
      if (res.status === 200 && res.json && res.json.ok) {
        var d = res.json.data || {};
        state.submitMsg = (d.status === 'duplicate') ? t('st.duplicate') : t('st.submitted');
        if ($('submitOk')) { $('submitOk').textContent = state.submitMsg; }
        refreshState();
        loadEvents(false);
      } else {
        state.submitMsg = '';
        if ($('submitOk')) { $('submitOk').textContent = ''; }
        setErr($('submitErr'), errTextFor(res.status, res.json));
      }
      $('btnSubmit').disabled = !(state.turn && String(state.turn.state) === 'COLLECTING');
    });
  }

  /* ---------- F7 事件流（主通道 REST；契约 §3.4 / §4 F7 / §7 R1） ----------
     渲染规则与小程序端 clients/miniprogram/lib/event-view.js 逐条对齐（标签/正文/时间/可见性）。 */
  var TAIL = 50;

  function evLabel(type) {
    var key = 'ev.' + type;
    return (key in S) ? S[key] : t('ev.OTHER') + ' ' + String(type || '');
  }

  function pickPath(obj, pathParts) {
    var cur = obj;
    for (var i = 0; i < pathParts.length; i++) {
      if (cur === null || cur === undefined || typeof cur !== 'object') { return undefined; }
      cur = cur[pathParts[i]];
    }
    return cur;
  }

  /* 可见性过滤（R1：REST 事件流无服务端过滤，客户端必须自行过滤） */
  function isVisible(ev) {
    var p = (ev && ev.payload) || {};
    var scope = p.scope;
    if (scope === undefined || scope === null || scope === 'public') { return true; }
    var targets = Array.isArray(p.targets) ? p.targets : [];
    var mine = targets.indexOf(state.playerId) >= 0;
    if (scope === 'whisper') { return mine; }
    if (scope === 'condition') { return mine || p.condition_met === true; }
    return true;
  }

  var TEXT_PATHS = [
    ['text'], ['body'], ['body_ref'], ['label'], ['message'], ['summary'],
    ['seg', 'text'], ['action', 'text'], ['next_preview'], ['line'], ['reason'],
    ['ref'], ['clue_id'], ['transcript_ref'], ['truth_tree_ref'], ['summary_ref'],
    ['role_ref'], ['npc_id'], ['op'], ['level'], ['status_text'], ['info_id']
  ];

  /* 事件正文（与小程序端 event-view.js::text 逐条一致） */
  function evText(ev) {
    var p = (ev && ev.payload) || {};
    var type = String((ev && ev.type) || '');
    if (type === 'ACTION_SUBMITTED') {
      var who = String(p.player_id || (ev && ev.actor) || '');
      var action = (p.action && p.action.text) ? p.action.text : JSON.stringify(p.action || {});
      var intent = p.intent_summary ? '（' + p.intent_summary + '）' : '';
      return who + '：' + action + intent;
    }
    if (type === 'TURN_STARTED') { return '第 ' + String(p.turn_no) + ' 回合'; }
    if (type === 'TURN_CLOSED') { return '第 ' + String(p.turn_no) + ' 回合结束'; }
    if (type === 'CHECK_RESOLVED') {
      return String(p.card_id || '') + ' 目标 ' + String(p.target) + ' 难度 ' + String(p.difficulty) +
        ' 合计 ' + String(p.total) + ' · ' + String(p.level);
    }
    if (type === 'VOTE_CAST') { return String(p.player_id || '') + ' → ' + String(p.target_player_id || ''); }
    if (type === 'ROLE_ASSIGNED') { return String(p.player_id || '') + ' · ' + String(p.role_ref || ''); }
    if (type === 'EVIDENCE_DEALT') { return String(p.location || '') + ' · ' + String(p.clue_id || ''); }
    for (var i = 0; i < TEXT_PATHS.length; i++) {
      var value = pickPath(p, TEXT_PATHS[i]);
      if (typeof value === 'string' && value) { return value; }
    }
    return JSON.stringify(p);
  }

  function ingestEvents(list) {
    if (!Array.isArray(list)) { return; }
    for (var i = 0; i < list.length; i++) {
      var ev = list[i];
      if (!ev || typeof ev.seq !== 'number') { continue; }
      /* 游标只由轮询推进（§3.4.2）：不可见事件也推进游标，保证不重复拉取 */
      if (ev.seq > state.cursor) { state.cursor = ev.seq; }
      if (!isVisible(ev)) { continue; }        /* R1：不可见事件不入列表 */
      var key = String(ev.seq);
      /* 去重键 = seq（与 WS 帧共用同一键空间）。契约 §3.4.2 竞态规则（队长裁决）：
         **轮询结果覆盖同 seq 的 WS 帧条目** —— REST 是主通道与权威表示（标签按 §5.2 ev.* 映射），
         且覆盖规则与网络时序无关（确定性），故此处不跳过、直接重写该键。 */
      state.items[key] = {
        id: key, order: ev.seq, seq: ev.seq,
        kind: evLabel(ev.type), text: evText(ev), time: hmsFromTs(ev.ts)
      };
    }
    if (state.tableId) { lsSet(LAST_SEQ_PREFIX + state.tableId, String(state.cursor)); }
    render();
  }

  /* F7 主通道：GET /api/campaigns/{campaign}/events（契约 §3.4.1 / §4.1 F7）
     取数做法 (a)：首次 since=-1&limit=1000 → 客户端取最新 50 条；
     增量 since=<游标>&limit=50；任一请求拉满（条数 == limit）则用推进后的游标续拉，最多 3 轮。
     请求一律带 ?token=<mobile token>（前向兼容，服务端当前忽略）。 */
  var FIRST_LIMIT = 1000;
  function loadEvents(initial, round) {
    if (!state.joined || !state.campaign) { return Promise.resolve(); }
    var attempt = round || 0;
    var limit = initial ? FIRST_LIMIT : TAIL;
    var since = initial ? -1 : state.cursor;
    /* R9：改走 mobile 端事件流 —— 服务端按 viewer 权威裁剪后才下发，
       客户端只拿可见 DTO（不再下发全量后靠前端隐藏）。 */
    var path = '/access/mobile/events?table_id=' + encodeURIComponent(state.tableId) +
      '&viewer=' + encodeURIComponent(state.playerId) +
      '&since=' + since + '&limit=' + limit +
      '&token=' + encodeURIComponent(state.token);
    return api(path).then(function (res) {
      if (res.status !== 200 || !res.json) {
        if (res.status === 0) { setErr($('eventsErr'), t('err.net')); }
        return;
      }
      setErr($('eventsErr'), '');
      /* /access/* 是统一包裹 {ok,data}；/api/* 是裸对象 —— 两者都兼容 */
      var body = (res.json && res.json.ok === true && res.json.data) ? res.json.data : res.json;
      var list = (body && body.events) || [];
      ingestEvents(list);
      if (list.length >= limit && attempt < 2) { return loadEvents(false, attempt + 1); }
    });
  }

  /* 按 seq 降序渲染（最新在最上），展示最新 TAIL 条（契约 §4 F7 / §4.1） */
  function render() {
    var all = [];
    for (var k in state.items) {
      if (Object.prototype.hasOwnProperty.call(state.items, k)) { all.push(state.items[k]); }
    }
    all.sort(function (a, b) { return b.order - a.order; });
    var newest = all.slice(0, TAIL);
    if (all.length > 200) {
      var keep = {};
      for (var j = 0; j < 200; j++) { keep[all[j].id] = all[j]; }
      state.items = keep;
    }
    var box = $('events');
    var html = '';
    for (var i = 0; i < newest.length; i++) {
      var e = newest[i];
      html += '<div class="item ev-item"><span class="ev-kind">' + escapeHtml(e.kind) + '</span>' +
        '<span class="ev-ts">#' + escapeHtml(String(e.seq)) + ' ' + escapeHtml(e.time) + '</span>' +
        '<div class="ev-text">' + escapeHtml(e.text) + '</div></div>';
    }
    box.innerHTML = html;
    box.scrollTop = 0;
  }

  /* ---------- F10 连接状态 + WS（可选增强通道；契约 §3） ---------- */
  /* 心跳语义（契约 §3.2/§3.5）：以「收到服务端 PING」为准 —— 服务端每 15s 下发 PING；
     客户端**不上行 PING**（服务端忽略上行 PING、无 PONG），只把任何收到的帧（含 PING）
     计入 lastFrameTs；连续 30s 无任何帧才主动重连（带 last_seq）。 */
  var BACKOFF = [1, 2, 4, 8, 30];
  var IDLE_LIMIT_MS = 30000;
  var KNOWN_KINDS = {
    STATE_DELTA: 1, TURN_UPDATED: 1, NARRATION_PENDING: 1, NARRATION_APPROVED: 1,
    WHISPER: 1, INFO_REVEALED: 1, BRANCH_TAKEN: 1, JOB_STATUS: 1,
    NPC_ACT_PROPOSED: 1, NPC_ACT_APPROVED: 1
  };

  /* WS 帧正文（与小程序端 lib/ws-client.js::frameText 逐条一致；契约 §3.4 可选增强通道） */
  function frameText(f) {
    if (!f) { return ''; }
    var kind = f.kind;
    if (kind === 'STATE_DELTA') {
      var delta = f.delta || {};
      return tpl('ext.ev.delta', { delta: delta.text || delta.message || delta.summary || JSON.stringify(delta) });
    }
    if (kind === 'TURN_UPDATED') {
      var turn = f.turn || {};
      return tpl('ext.ev.turn', { turn_no: (turn.turn_no === undefined ? '-' : turn.turn_no), state: turn.state || '' });
    }
    if (kind === 'NARRATION_PENDING') {
      var ptext = String((f.proposal || {}).text || '');
      return t('ext.ev.narrationPending') + (ptext ? ' · ' + ptext : '');
    }
    if (kind === 'NARRATION_APPROVED') { return String((f.narration || {}).text || ''); }
    if (kind === 'WHISPER') { return tpl('ext.ev.directed', { body: String((f.packet || {}).body || '') }); }
    if (kind === 'INFO_REVEALED') {
      var packet = f.packet || {};
      var body = String(packet.body || '');
      return tpl('ext.ev.info', { info_id: packet.info_id || '' }) + (body ? ' · ' + body : '');
    }
    if (kind === 'BRANCH_TAKEN') {
      var branch = f.branch || {};
      return tpl('ext.ev.branch', { label: branch.label || branch.node_id || '' });
    }
    if (kind === 'JOB_STATUS') {
      var job = f.job || {};
      return tpl('ext.ev.job', { job_id: job.job_id || '', status: job.status || '' });
    }
    return JSON.stringify(f);
  }

  function frameTime(ts) {
    if (ts === undefined || ts === null || ts === '') { return ''; }
    var value = ts;
    if (typeof value === 'number' && value < 1e12) { value = value * 1000; }
    var d = new Date(value);
    if (isNaN(d.getTime())) { return String(ts); }
    var p = function (n) { return String(n).length < 2 ? '0' + n : String(n); };
    return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
  }

  /* WS 增强帧处置（契约 §3.4.2，两端逐字一致）：
     - 帧 seq <= 本地 last_seq → 直接丢弃（已被轮询覆盖或已显示过）
     - 帧 seq >  last_seq → 渲染（插入顶部、保持降序），但**不推进** last_seq
     - 去重键 = seq，与轮询结果共用同一键空间 */
  function pushWsFrame(f) {
    if (typeof f.seq !== 'number') { return; }
    if (f.seq <= state.cursor) { return; }
    var key = String(f.seq);
    if (state.items[key]) { return; }
    state.items[key] = {
      id: key, order: f.seq, seq: f.seq,
      kind: String(f.kind), text: frameText(f), time: frameTime(f.ts)
    };
    render();
  }

  function wsUrl() {
    var wsBase = normalizeServer(state.server)
      .replace(/^http:/i, 'ws:').replace(/^https:/i, 'wss:');
    /* 契约 §1.4：真实 WS 路径是 /ws；禁止使用 /access/info 的 data.ws 字段 */
    return wsBase + '/ws?table=' + encodeURIComponent(state.tableId) +
      '&viewer=' + encodeURIComponent(state.playerId) +
      '&role=pl&last_seq=' + state.cursor +
      '&token=' + encodeURIComponent(state.token);
  }

  /* F10 状态行：四态**只由轮询驱动**（契约 §3.4.2：WS 连不上/403/被拒/断开 → 静默降级，
     不得报错、不得阻塞 UI、**不得改变任何文案**）。因此 WS 状态只记在内存，不写任何可见文案。 */
  function setConnStatus(s) {
    state.connState = s;
    if ($('wsStatus')) { $('wsStatus').textContent = t('st.' + s); }
  }

  function connectWs() {
    closeWs();
    if (!state.joined) { return; }
    var ws;
    try { ws = new WebSocket(wsUrl()); } catch (e) { scheduleReconnect(); return; }
    state.ws = ws;
    ws.onopen = function () {
      state.backoffIdx = 0;
      state.lastFrameTs = Date.now();
      startWatchdog();
      /* R12 断线重连自动追平：重连成功立即按本地游标拉齐（无需用户操作/刷新） */
      state.cursor = parseInt(lsGet(LAST_SEQ_PREFIX + state.tableId) || String(state.cursor), 10);
      if (isNaN(state.cursor)) { state.cursor = -1; }
      refreshState();
      loadEvents(false);
    };
    ws.onmessage = function (ev) {
      state.lastFrameTs = Date.now();
      var f = null;
      try { f = JSON.parse(ev.data); } catch (e) { return; }
      if (!f || typeof f !== 'object') { return; }
      if (f.kind === 'PING') { return; }          /* PING 只刷新心跳（上方已置 lastFrameTs），不进事件列表 */
      if (!KNOWN_KINDS[f.kind]) { return; }        /* ACK / ERROR 等未知 kind 一律忽略（契约 §3.3） */
      pushWsFrame(f);                              /* 先按帧立即渲染（最快路径） */
      /* R12：推送驱动 —— 帧到达即拉权威事件流。游标仍只由 REST 拉取推进
         （保证 WS 漏帧时不跳过中间 seq），但**不再等 2s/15s 轮询**。 */
      pushRefresh();
    };
    ws.onclose = function () {
      stopWatchdog();
      if (state.ws !== ws) { return; }
      state.ws = null;
      scheduleReconnect();
    };
    ws.onerror = function () { /* onclose 统一处理；WS 失败不阻塞 UI（§3.1） */ };
  }

  function closeWs() {
    stopWatchdog();
    var ws = state.ws;
    state.ws = null;
    if (ws) { try { ws.onclose = null; ws.close(); } catch (e) { /* ignore */ } }
  }

  function scheduleReconnect() {
    if (!state.joined) { return; }
    var delay = BACKOFF[Math.min(state.backoffIdx, BACKOFF.length - 1)];
    state.backoffIdx = state.backoffIdx + 1;
    window.setTimeout(function () { if (state.joined) { connectWs(); } }, delay * 1000);
  }

  function startWatchdog() {
    stopWatchdog();
    state.watchTimer = window.setInterval(function () {
      if (Date.now() - state.lastFrameTs > IDLE_LIMIT_MS) {
        state.lastFrameTs = Date.now();
        connectWs();     /* 30s 无任何帧：主动重连 */
      }
    }, 5000);
  }
  function stopWatchdog() {
    if (state.watchTimer) { window.clearInterval(state.watchTimer); state.watchTimer = null; }
  }

  /* ---------- F8 语音录制与上传 ---------- */
  function recSupported() {
    var nav = window.navigator || {};
    return !!(nav.mediaDevices && nav.mediaDevices.getUserMedia && window.MediaRecorder);
  }
  function startRecording() {
    setErr($('recErr'), '');
    $('recOk').textContent = '';
    if (!recSupported()) {
      setErr($('recErr'), t('ext.st.recordUnsupported'));
      return;
    }
    if (!state.joined || !state.campaign) {
      setErr($('recErr'), t('ext.st.needCode'));
      return;
    }
    window.navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
      state.mediaStream = stream;
      state.chunks = [];
      var mr = new MediaRecorder(stream);
      state.mediaRecorder = mr;
      mr.ondataavailable = function (ev) { if (ev.data && ev.data.size > 0) { state.chunks.push(ev.data); } };
      mr.onstop = function () { uploadRecording(); };
      mr.start();
      $('btnRecStart').disabled = true;
      $('btnRecStop').disabled = false;
      $('recStatus').textContent = t('ext.st.recording');
    }, function () {
      setErr($('recErr'), t('ext.st.recordUnsupported'));
    });
  }
  function stopRecording() {
    var mr = state.mediaRecorder;
    if (!mr) { return; }
    try { mr.stop(); } catch (e) { /* ignore */ }
    $('btnRecStart').disabled = false;
    $('btnRecStop').disabled = true;
    if (state.mediaStream) {
      try { state.mediaStream.getTracks().forEach(function (tr) { tr.stop(); }); } catch (e) { /* ignore */ }
      state.mediaStream = null;
    }
  }
  function uploadRecording() {
    var blob = new Blob(state.chunks, { type: 'audio/webm' });
    state.chunks = [];
    if (!blob.size) {
      setErr($('recErr'), t('err.server'));
      return;
    }
    var fd = new FormData();
    fd.append('file', blob, 'voice.webm');
    fd.append('campaign', state.campaign);
    fd.append('kind', 'voice');
    fd.append('player_id', state.playerId);
    $('recStatus').textContent = t('st.connecting');
    api('/access/player/audio', { method: 'POST', body: fd, form: true }).then(function (res) {
      $('recStatus').textContent = t('st.connected');
      if (res.status === 200 && res.json && res.json.ok) {
        var d = res.json.data || {};
        var line = tpl('ext.st.uploadOk', { bytes: (d.bytes === undefined ? blob.size : d.bytes) });
        /* file_ref 只显示文件名部分（两端一致）：不回显服务端绝对路径 */
        if (d.file_ref) {
          var parts = String(d.file_ref).split(/[\\/]/);
          line += ' · ' + parts[parts.length - 1];
        }
        if (d.stt && d.stt.status) { line += ' · ' + tpl('ext.st.sttStatus', { status: d.stt.status }); }
        $('recOk').textContent = line;
      } else {
        setErr($('recErr'), errTextFor(res.status, res.json));
      }
    });
  }

  /* ---------- F9 录音设备状态（只读） ---------- */
  function queryDevice() {
    setErr($('deviceErr'), '');
    $('deviceOut').innerHTML = '';
    var id = String($('deviceId').value || '').trim();
    if (!id) { setErr($('deviceErr'), t('ph.deviceId')); return; }
    api('/access/device/status?device_id=' + encodeURIComponent(id)).then(function (res) {
      if (res.status === 404) { setErr($('deviceErr'), t('st.noDevice')); return; }
      if (res.status !== 200 || !res.json || !res.json.ok) {
        setErr($('deviceErr'), errTextFor(res.status, res.json));
        return;
      }
      var d = res.json.data || {};
      var keys = ['device_id', 'status_text', 'recording', 'flagged', 'battery', 'note', 'ts', 'seq'];
      var html = '';
      for (var i = 0; i < keys.length; i++) {
        var k = keys[i];
        if (d[k] === undefined) { continue; }
        html += '<div class="kv"><span class="k">' + escapeHtml(k) + '</span><span>' +
          escapeHtml(String(d[k])) + '</span></div>';
      }
      $('deviceOut').innerHTML = html;
    });
  }

  /* ---------- T15 (additive): R10/R11 地点交互面板 ----------
     只新增：不改既有轮询/WS/提交链路；动作集与热区锚点全部由服务端下发
     （GET /api/campaigns/{c}/interactives -> anchor/actions；POST .../interact）。
     敏感动作走既有审批总线（服务端返回 pending_approval -> 玩家进入「已上报待主持人」）。 */
  var IX = { objects: [], rooms: [], selId: '', busy: false, mounted: false,
             lastMine: 0, lastLoad: 0, loadedCampaign: '', lastLabel: '', pendingLabel: '' };
  var IX_LOAD_MS = 5000;
  var IX_MINE_MS = 2500;
  /* 家具种类 -> 短标签（热区按钮用；避免长名称溢出，见 R33 碰撞判据） */
  var IX_KIND = {
    cabinet: '柜子', desk: '书桌', drawer: '抽屉', door: '门', safe: '保险箱',
    shelf: '架子', locker: '柜子', chest: '箱子', box: '箱子', table: '桌子',
    bed: '床', window: '窗', painting: '画', statue: '雕像', furniture: '家具'
  };

  function ixShort(o) { return IX_KIND[o.kind] || String(o.name || o.id); }

  function ixMount() {
    if (IX.mounted || !$('viewTable')) { return; }
    var card = document.createElement('div');
    card.className = 'card';
    card.id = 'ixCard';
    card.innerHTML =
      '<h2 class="card-title">' + escapeHtml(t('ix.title')) + '</h2>' +
      '<div class="status-line" id="ixRoom"></div>' +
      '<div id="ixMap" style="position:relative;height:150px;margin:var(--space-sm) 0;' +
      'border:1px solid var(--color-border);border-radius:var(--radius-card);overflow:hidden"></div>' +
      '<div class="actions" id="ixActions"></div>' +
      '<div class="events" id="ixList"></div>' +
      '<div class="row" style="margin-top:8px"><div class="ok-line" id="ixOut"></div></div>' +
      '<div class="status-line" id="ixMine"></div>' +
      '<div id="ixErr" class="err-bar hidden"></div>';
    $('viewTable').appendChild(card);
    IX.mounted = true;
  }

  function ixLoad() {
    if (!state.joined || !state.campaign) { return Promise.resolve(); }
    if (IX.loadedCampaign !== state.campaign) { IX.loadedCampaign = state.campaign; IX.selId = ''; }
    return api('/api/campaigns/' + encodeURIComponent(state.campaign) + '/interactives?viewer=' +
               encodeURIComponent(state.playerId || '')).then(function (res) {
      if (res.status !== 200 || !res.json) { setErr($('ixErr'), errTextFor(res.status, res.json)); return; }
      setErr($('ixErr'), '');
      IX.objects = res.json.objects || [];
      IX.rooms = res.json.rooms || [];
      var still = false;
      for (var i = 0; i < IX.objects.length; i++) { if (IX.objects[i].id === IX.selId) { still = true; } }
      if (!still) { IX.selId = ''; }
      ixRender();
    });
  }

  function ixRender() {
    if (!IX.mounted) { return; }
    var room = IX.rooms.length ? IX.rooms[0] : null;
    $('ixRoom').textContent = room
      ? tpl('ix.room', { room: room.name || room.id, n: IX.objects.length })
      : (IX.objects.length ? tpl('ix.all', { n: IX.objects.length }) : t('ix.none'));
    var map = $('ixMap');
    map.innerHTML = '';
    if (room) {
      var w = map.clientWidth || 320;
      var s = Math.min(w / Math.max(room.w || 1, 1), 150 / Math.max(room.h || 1, 1));
      for (var i = 0; i < IX.objects.length; i++) {
        if (String(IX.objects[i].room) !== String(room.id)) { continue; }   /* 只画本房间热区 */
        (function (o) {
          var b = document.createElement('button');
          b.type = 'button';
          b.className = 'btn' + (o.id === IX.selId ? ' btn-primary' : '');
          b.setAttribute('data-ix-hot', o.id);
          b.textContent = ixShort(o);
          b.style.position = 'absolute';
          b.style.left = Math.round((o.anchor.x - room.x) * s) + 'px';
          b.style.top = Math.round((o.anchor.y - room.y) * s) + 'px';
          b.style.padding = '2px 8px';
          b.style.fontSize = '12px';
          b.onclick = function () { ixSelect(o.id); };
          map.appendChild(b);
        })(IX.objects[i]);
      }
    }
    var html = '';
    for (var j = 0; j < IX.objects.length; j++) {
      var o = IX.objects[j];
      html += '<div class="item ev-item"><span class="ev-kind">' + escapeHtml(ixShort(o)) + '</span>' +
        '<span class="ev-ts">' + escapeHtml(String(o.room)) + '</span>' +
        '<div class="ev-text">' + escapeHtml(o.name) + '</div></div>';
    }
    $('ixList').innerHTML = html;
    ixRenderActions();
  }

  function ixSelected() {
    for (var i = 0; i < IX.objects.length; i++) {
      if (IX.objects[i].id === IX.selId) { return IX.objects[i]; }
    }
    return null;
  }

  function ixRenderActions() {
    var box = $('ixActions');
    if (!box) { return; }
    box.innerHTML = '';
    var obj = ixSelected();
    if (!obj) { box.textContent = t('ix.pick'); return; }
    box.textContent = '';
    var acts = obj.actions || [];
    for (var k = 0; k < acts.length; k++) {
      (function (a) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = a.sensitive ? 'btn' : 'btn-primary';
        b.setAttribute('data-ix-action', a.action);
        b.textContent = String(a.label || a.action) + (a.sensitive ? t('ix.report') : '');
        b.disabled = !!IX.busy;
        b.onclick = function () { ixAct(obj.id, a.action); };
        box.appendChild(b);
      })(acts[k]);
    }
  }

  function ixSelect(id) { IX.selId = id; ixRender(); }

  function ixAct(objectId, action) {
    if (IX.busy || !state.joined || !state.campaign) { return; }
    IX.busy = true;
    setErr($('ixErr'), '');
    $('ixOut').textContent = '';
    ixRenderActions();
    api('/api/campaigns/' + encodeURIComponent(state.campaign) + '/interact', {
      method: 'POST',
      body: { player_id: state.playerId, object_id: objectId, action: action, req_id: newReqId() }
    }).then(function (res) {
      IX.busy = false;
      var j = res.json || {};
      if (res.status === 201 && j.status === 'ok') {
        var r = j.result || {};
        $('ixOut').textContent = String(r.text || '') +
          (r.level ? '（' + String(r.level) + (typeof r.rolled === 'number' ? ' d100=' + r.rolled : '') + '）' : '');
        loadEvents(false);
      } else if (res.status === 201 && j.status === 'pending_approval') {
        IX.lastLabel = String(j.label || '');
        IX.pendingLabel = IX.lastLabel;   /* 未决定期间：WS 帧到达即强制刷新（绕过节流） */
        $('ixOut').textContent = String(j.state || t('ix.pending')) + '：' + IX.lastLabel;
        ixMine(true);
      } else {
        setErr($('ixErr'), errTextFor(res.status, res.json));
      }
      ixRenderActions();
    });
  }

  function ixMine(force) {
    if (!state.joined || !state.campaign) { return; }
    var now = Date.now();
    if (!force && now - IX.lastMine < IX_MINE_MS) { return; }
    IX.lastMine = now;
    api('/api/campaigns/' + encodeURIComponent(state.campaign) + '/pipeline/mine?player_id=' +
        encodeURIComponent(state.playerId || '')).then(function (res) {
      if (res.status !== 200 || !res.json) { return; }
      var items = res.json.items || [];
      var lines = [];
      for (var i = 0; i < items.length; i++) {
        var it = items[i];
        var st = String(it.state) === '已下发' ? t('ix.delivered')
          : (String(it.state) === '已驳回' ? t('ix.rejected') : t('ix.pending'));
        lines.push(String(it.label || '') + ' · ' + st + (it.text ? '：' + String(it.text) : ''));
        /* 主持人已决定 -> 就地刷新结果行（无需手动刷新页面） */
        if (IX.lastLabel && String(it.label) === IX.lastLabel && it.text) {
          $('ixOut').textContent = st + '：' + String(it.text);
        }
        if (IX.pendingLabel && String(it.label) === IX.pendingLabel &&
            (String(it.state) === '已下发' || String(it.state) === '已驳回')) {
          IX.pendingLabel = '';   /* 已决定：恢复节流 */
        }
      }
      $('ixMine').textContent = lines.length ? (t('ix.mine') + '：' + lines.join(' ｜ ')) : '';
    });
  }

  function ixRefresh() {
    if (!state.joined) { return; }
    ixMine(!!IX.pendingLabel);   /* 自己有未决定的报备 -> 强制刷新，避免漏掉下发 */
    var now = Date.now();
    if (now - IX.lastLoad < IX_LOAD_MS) { return; }
    IX.lastLoad = now;
    ixLoad();
  }

  function ixStart() {
    ixMount();
    IX.selId = '';
    IX.lastMine = 0;
    IX.lastLoad = Date.now();
    ixLoad();
    ixMine(true);
  }

  function ixStop() {
    IX.objects = [];
    IX.rooms = [];
    IX.selId = '';
    if (IX.mounted) { ixRender(); }
  }

  /* ---------- 初始化 ---------- */
  function applyPrefs() {
    var qs = window.location.search || '';
    var q = {};
    qs.replace(/^\?/, '').split('&').forEach(function (kv) {
      if (!kv) { return; }
      var i = kv.indexOf('=');
      var k = i < 0 ? kv : kv.slice(0, i);
      var v = i < 0 ? '' : decodeURIComponent(kv.slice(i + 1).replace(/\+/g, ' '));
      q[k] = v;
    });
    var server = q.server || lsGet(LS.server) || window.location.origin;
    $('server').value = server;
    $('token').value = q.token || lsGet(LS.token) || '';
    $('code').value = q.code || lsGet(LS.code) || '';
    $('pid').value = q.pid || lsGet(LS.playerId) || '';
    $('pname').value = lsGet(LS.playerName) || '';
    state.server = normalizeServer(server);
    state.token = $('token').value;
    state.code = $('code').value;
    state.playerId = $('pid').value;
    state.playerName = $('pname').value;
  }

  function bind() {
    $('navSetup').onclick = function () { showView('setup'); };
    $('navTable').onclick = function () { showView('table'); };
    $('navVoice').onclick = function () { showView('voice'); };
    $('btnTest').onclick = function () { testConnection(); };
    $('btnResolve').onclick = function () { resolveCode(); };
    $('btnJoin').onclick = function () { joinTable(); };
    $('btnLeave').onclick = function () { leaveTable(); };
    $('btnSubmit').onclick = function () { submitAction(); };
    $('btnRecStart').onclick = function () { startRecording(); };
    $('btnRecStop').onclick = function () { stopRecording(); };
    $('btnQuery').onclick = function () { queryDevice(); };
    window.addEventListener('beforeunload', function () { closeWs(); });
  }

  function init() {
    bind();
    ixMount();   /* T15 (additive): 挂载地点交互面板（纯 DOM 注入，不改 index.html） */
    applyPrefs();
    renderTurn();
    render();
    setConnStatus('closed');
    $('setupStatus').textContent = t('st.closed');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
