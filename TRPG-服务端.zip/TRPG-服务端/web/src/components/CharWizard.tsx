import React from 'react';
import { ErrorBanner } from './ui';
// UI-R2: 灰白黑令牌适配（仅视觉）

const STEPS = ['概念', '属性', '技能', '背景', '确认'] as const;

const ATTR_BASE = [
  { name: 'STR', value: 55 }, { name: 'CON', value: 60 }, { name: 'SIZ', value: 65 },
  { name: 'DEX', value: 70 }, { name: 'APP', value: 50 }, { name: 'INT', value: 80 },
  { name: 'POW', value: 75 }, { name: 'EDU', value: 82 },
];

export function CharWizard(): React.ReactElement {
  const [step, setStep] = React.useState(0);
  const [name, setName] = React.useState('林墨');
  const [job, setJob] = React.useState('侦探');
  const [attrs, setAttrs] = React.useState(ATTR_BASE.map((a) => ({ ...a })));
  const [skills, setSkills] = React.useState({ 侦查: 45, 聆听: 40, 闪避: 35 });
  const [background, setBackground] = React.useState('雾港警局前探员，因一桩旧案回到这座城市。');
  const [error, setError] = React.useState('');
  const [done, setDone] = React.useState(false);
  const [savedTick, setSavedTick] = React.useState(0);

  const attrSum = attrs.reduce((s, a) => s + a.value, 0);
  const skillSum = Object.values(skills).reduce((s, v) => s + v, 0);

  const validate = (s: number): string => {
    if (s === 0 && !name.trim()) return '请填写调查员姓名。';
    if (s === 4) {
      if (!name.trim()) return '请返回第一步填写姓名。';
      if (skillSum > 4000) return `技能总和 ${skillSum} 超出上限 4000。`;
    }
    return '';
  };

  const next = (): void => {
    const msg = validate(step + 1 <= 4 ? step + 1 : step);
    if (msg) { setError(msg); return; }
    setError('');
    if (step === 4) { setDone(true); return; }
    setStep((v) => Math.min(4, v + 1));
  };
  const back = (): void => { setError(''); setDone(false); setStep((v) => Math.max(0, v - 1)); setSavedTick((t) => t + 1); };

  const setAttr = (name_: string, delta: number): void => {
    setAttrs((prev) => prev.map((a) => (a.name === name_ ? { ...a, value: Math.min(100, Math.max(1, a.value + delta)) } : a)));
  };

  return (
    <div className="space-y-4">
      <section className="panel" aria-label="车卡步骤">
        <p className="mb-2 text-[11px] text-gray-500">车卡步骤（共 5 步，当前步骤高亮）</p>
        <ol className="flex flex-wrap gap-2" aria-label="车卡进度">
          {STEPS.map((label, i) => (
            <li key={label} className={`chip ${i === step ? 'border-black bg-black text-white' : i < step ? 'border-gray-400 text-gray-800' : 'text-gray-500'}`} aria-current={i === step ? 'step' : undefined}>
              {i + 1}. {label}{i < step ? ' ✓' : ''}
            </li>
          ))}
        </ol>
        {error ? <div className="mt-3" role="alert" aria-live="assertive" aria-atomic="true"><ErrorBanner message={`${error}（第 ${step + 1} 步 · ${STEPS[step]}）`} onClose={() => setError('')} /></div> : null}
        {savedTick > 0 && !error ? <p className="mt-2 text-xs text-gray-800" role="status">草稿已保存（回退时自动保存，可随时回退修改；中途离开需先回退一次）。</p> : null}
      </section>

      {done ? (
        <section className="panel" aria-label="建卡完成">
          <h2 className="panel-title">建卡完成（校验通过）</h2>
          <p className="text-sm">调查员 <b>{name}</b> · {job} · 属性和 {attrSum} · 技能和 {skillSum}</p>
          <div className="mt-3 flex gap-2">
            <button className="btn btn-secondary" onClick={back}>回退修改</button>
            <button className="btn btn-primary" onClick={() => setError('演示模式：角色已生成，联网后可入桌。')}>确认入桌</button>
          </div>
        </section>
      ) : null}

      {step === 0 ? (
        <section className="panel" aria-label="概念">
          <h2 className="panel-title">第 1 步 · 概念</h2>
          <label className="mb-1 block text-xs text-gray-500" htmlFor="cw-name">调查员姓名 <span className="text-gray-500">· 草稿可改，提交建卡前可随时回退修改</span></label>
          <input id="cw-name" className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="如：林墨" autoFocus />
          <label className="mb-1 mt-2 block text-xs text-gray-500" htmlFor="cw-job">职业 <span className="text-gray-500">· 草稿可改</span></label>
          <input id="cw-job" className="input" value={job} onChange={(e) => setJob(e.target.value)} placeholder="如：侦探" />
          <p className="mt-2 text-[11px] text-gray-500">姓名与职业为预填演示示例（草稿）：可直接修改，提交建卡后仍可回退修改，以你最终填写为准。</p>
        </section>
      ) : null}
      {step === 1 ? (
        <section className="panel" aria-label="属性分配">
          <h2 className="panel-title">第 2 步 · 属性（点击 ± 微调，和 {attrSum}）</h2>
          <ul className="grid grid-cols-2 gap-2 md:grid-cols-4">
            {attrs.map((a) => (
              <li key={a.name} className="rounded bg-gray-100 p-2 text-center">
                <div className="text-xs text-gray-500">{a.name}</div>
                <div className="text-lg font-bold">{a.value}</div>
                <div className="mt-1 flex justify-center gap-1">
                  <button className="btn btn-secondary px-2 py-1" onClick={() => setAttr(a.name, -5)} aria-label={`${a.name} 减 5`}>−5</button>
                  <button className="btn btn-secondary px-2 py-1" onClick={() => setAttr(a.name, 5)} aria-label={`${a.name} 加 5`}>＋5</button>
                </div>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
      {step === 2 ? (
        <section className="panel" aria-label="技能分配">
          <h2 className="panel-title">第 3 步 · 技能（和 {skillSum} / 上限 4000）</h2>
          <ul className="space-y-2">
            {Object.entries(skills).map(([k, v]) => (
              <li key={k} className="flex items-center gap-2 text-sm">
                <span className="w-16">{k}</span>
                <input type="range" min={0} max={100} value={v} onChange={(e) => setSkills((prev) => ({ ...prev, [k]: Number(e.target.value) }))} className="flex-1 accent-gray-900" aria-label={`${k}技能值`} />
                <span className="w-10 text-right font-mono">{v}</span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
      {step === 3 ? (
        <section className="panel" aria-label="背景">
          <h2 className="panel-title">第 4 步 · 背景</h2>
          <textarea className="input min-h-[96px]" value={background} onChange={(e) => setBackground(e.target.value)} placeholder="一句话人物小传…" aria-label="人物背景" />
        </section>
      ) : null}
      {step === 4 ? (
        <section className="panel" aria-label="确认">
          <h2 className="panel-title">第 5 步 · 确认（validate_card 规则预览）</h2>
          <ul className="space-y-1 text-sm text-gray-600">
            <li>姓名：{name || '（未填 — 提交将被拦截并提示）'}</li>
            <li>职业：{job}</li>
            <li>属性：{attrs.map((a) => `${a.name}${a.value}`).join(' / ')}</li>
            <li>技能：{Object.entries(skills).map(([k, v]) => `${k}${v}`).join(' / ')}</li>
          </ul>
        </section>
      ) : null}

      {!done ? (
        <div className="flex gap-2">
          <button className="btn btn-secondary" onClick={back} disabled={step === 0} title={step === 0 ? '已是第一步' : '回到上一步，草稿保留'}>上一步（回退）</button>
          <button className="btn btn-primary" onClick={next}>{step === 4 ? '提交建卡' : `下一步：${STEPS[Math.min(4, step + 1)]}`}</button>
        </div>
      ) : null}
    </div>
  );
}
