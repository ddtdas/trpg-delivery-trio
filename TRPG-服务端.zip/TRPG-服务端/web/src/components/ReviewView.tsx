import React from 'react';
import { transport } from '../lib/transport';
import { ensureReviewSubscription, useReviewStore } from '../store/review';
import { EmptyState, ErrorBanner, SkeletonRows } from './ui';
// UI-R2: 灰白黑令牌适配（仅视觉）

const KIND_FILTERS = ['全部', '检定', '叙事', '行动', '地图', '分支'] as const;
const KIND_ZH: Record<string, string> = {
  CAMPAIGN_STARTED: '开团', CHARACTER_CREATED: '建卡', TURN_STARTED: '回合开始',
  ACTION_SUBMITTED: '行动提交', CHECK_RESOLVED: '检定结算', NARRATION_PROPOSED: '旁白提案',
  NARRATION_APPROVED: '旁白已批准', NARRATION_EDITED: '旁白已编辑', NARRATION_REJECTED: '旁白已否决',
  BRANCH_TAKEN: '剧情分支', MAP_UPDATED: '地图更新', TURN_UPDATED: '回合更新',
};
function kindGroup(kind: string): string {
  if (kind.includes('CHECK')) return '检定';
  if (kind.includes('NARRATION')) return '叙事';
  if (kind.includes('ACTION') || kind.includes('TURN')) return '行动';
  if (kind.includes('MAP')) return '地图';
  if (kind.includes('BRANCH')) return '分支';
  return '其他';
}

/** ReviewView：复盘时间线（seq 序、筛选、详情、骰点/叙事对照、KP 标记）。 */
export function ReviewView(): React.ReactElement {
  const events = useReviewStore((s) => s.events);
  const [kindFilter, setKindFilter] = React.useState<(typeof KIND_FILTERS)[number]>('全部');
  const [actorFilter, setActorFilter] = React.useState('');
  const [openSeq, setOpenSeq] = React.useState<number | null>(null);

  const [reviewLoading, setReviewLoading] = React.useState(true);
  const [loadErr, setLoadErr] = React.useState(false);
  React.useEffect(() => {
    ensureReviewSubscription();
    transport.connect();
    const t = window.setTimeout(() => setReviewLoading(false), 500);
    const tErr = window.setTimeout(() => {
      if (useReviewStore.getState().events.length === 0) setLoadErr(true);
    }, 8000);
    return () => { window.clearTimeout(t); window.clearTimeout(tErr); };
  }, []);

  const actors = React.useMemo(() => [...new Set(events.map((e) => e.actor))], [events]);
  const shown = events.filter((e) => (kindFilter === '全部' || kindGroup(e.kind) === kindFilter) && (!actorFilter || e.actor === actorFilter));

  const badge = (kind: string): string => {
    if (kind === 'NARRATION_REJECTED') return 'border-red-500 bg-red-50 text-red-700';
    if (kind === 'NARRATION_EDITED' || kind === 'NARRATION_APPROVED') return 'border-gray-400 text-gray-800';
    if (kind.includes('CHECK')) return 'border-gray-400 text-gray-600';
    return 'border-gray-400 text-gray-600';
  };

  return (
    <div className="space-y-4">
      {loadErr ? (
        <ErrorBanner message="复盘加载超时：8 秒内未收到事件流。请检查与主持端服务器的连接后重试。" onClose={() => window.location.reload()} />
      ) : null}
      <section className="panel" aria-label="复盘筛选">
        <h2 className="panel-title">复盘 · 事件时间线（{shown.length}/{events.length}）</h2>
        <p className="mb-2 text-xs text-gray-500">时间线只读：复盘数据来自事件流快照（保存 / 同步状态见后端事件审计）。</p>
        <div className="flex flex-wrap gap-2">
          {KIND_FILTERS.map((k) => (
            <button key={k} className={`chip ${kindFilter === k ? 'border-gray-400 bg-gray-100 text-gray-800' : 'text-gray-500'}`} onClick={() => setKindFilter(k)} aria-pressed={kindFilter === k}>{k}</button>
          ))}
          <select className="input max-w-[180px]" value={actorFilter} onChange={(e) => setActorFilter(e.target.value)} aria-label="按角色筛选">
            <option value="">全部角色</option>
            {actors.map((a) => (<option key={a} value={a}>{a}</option>))}
          </select>
          {(kindFilter !== '全部' || actorFilter) ? (
            <button className="chip border-gray-400 text-gray-700" onClick={() => { setKindFilter('全部'); setActorFilter(''); }} aria-label="清除筛选">清除筛选 ✕</button>
          ) : null}
        </div>
      </section>
      <ol className="space-y-2" aria-live="polite" aria-atomic="true">
        {reviewLoading ? <SkeletonRows rows={4} label="复盘时间线加载中" /> : null}
        <div className="min-h-[8px]" aria-live="polite" aria-atomic="true" />
        {!reviewLoading && shown.length === 0 ? <EmptyState text="没有命中筛选的事件 —— 点「清除筛选」回到全部，或等 KP 推进回合产生新事件。" /> : null}
        {!reviewLoading ? shown.map((e) => (
          <li key={e.seq} className="rounded-lg border border-gray-200 bg-white p-3">
            <button className="flex w-full items-center gap-2 text-left" onClick={() => setOpenSeq((v) => (v === e.seq ? null : e.seq))} aria-expanded={openSeq === e.seq} aria-label={`事件 ${e.seq} 详情`}>
              <span className="font-mono text-xs text-gray-600">#{e.seq}</span>
              <span className={`chip ${badge(e.kind)}`} title={e.kind}>{KIND_ZH[e.kind] ?? e.kind}</span>
              <span className="text-sm text-gray-800">{e.summary}</span>
              <span className="ml-auto text-xs text-gray-700">{e.actor}</span>
            </button>
            {openSeq === e.seq ? (
              <div className="mt-2 rounded bg-gray-100 p-2 text-sm leading-6 text-gray-700">
                <p>{e.detail}</p>
                {e.kind === 'CHECK_RESOLVED' ? <p className="mt-1 text-xs text-gray-600">对照：骰点结果 ↔ 叙事影响（KP 定夺后写入旁白）</p> : null}
                {e.kind === 'NARRATION_REJECTED' ? <p className="mt-1 text-xs text-red-700">KP 标记：已否决（打回重写，不入正史）</p> : null}
                {e.kind === 'NARRATION_APPROVED' ? <p className="mt-1 text-xs text-gray-800">KP 标记：已批准（入正史，可引用）</p> : null}
              </div>
            ) : null}
          </li>
        )) : null}
      </ol>
    </div>
  );
}
