import { create } from 'zustand';
import type { SendableClientFrame } from '../lib/mockTransport';
import { transport } from '../lib/transport';

export type MapOpKind = 'move' | 'add_token' | 'set_fog' | 'set_status' | 'set_light';
export type TokenStatus = 'settled' | 'pending' | 'rejected';

export interface MapToken {
  id: string;
  label: string;
  x: number;
  y: number;
  room: string;
  visible: boolean;
  status: TokenStatus;
}

interface MapState {
  tokens: MapToken[];
  fog: Record<string, boolean>;
  pendingOp: { op: MapOpKind; target: string; note: string } | null;
  error: string;
  log: Array<{ text: string; ts: number; actor: string }>;
  selectedId: string | null;
  set: (p: Partial<MapState>) => void;
  reset: () => void;
}

const initialTokens: MapToken[] = [
  { id: 'linmo', label: '林', x: 60, y: 60, room: 'r_lobby', visible: true, status: 'settled' },
  { id: 'surui', label: '苏', x: 120, y: 100, room: 'r_lobby', visible: true, status: 'settled' },
  { id: 'npc_clerk', label: '员', x: 300, y: 60, room: 'r_reading', visible: true, status: 'settled' },
];

const initial: Omit<MapState, 'set' | 'reset'> = {
  tokens: initialTokens,
  fog: { r_secret: true },
  pendingOp: null,
  error: '',
  log: [{ text: '地图已载入：密斯卡托尼克大学图书馆（一层）', ts: Date.now(), actor: 'system' }],
  selectedId: 'linmo',
};

export const useMapStore = create<MapState>()((set) => ({
  ...initial,
  set: (p) => set(p),
  reset: () => set({ ...initial, tokens: initialTokens.map((t) => ({ ...t })) }),
}));

let reqSeq = 7000;
function reqId(): string {
  reqSeq += 1;
  return `map-${Date.now()}-${reqSeq}`;
}

/** 地图命令经 transport 单一入口（COMMAND map 走命令链；审批由后端裁决）。 */
export function mapSend(op: MapOpKind, target: string, delta: Record<string, unknown>): void {
  transport.send({
    kind: 'COMMAND',
    cmd: { type: 'map', payload: { map_id: 'map_library', op, target, delta } },
  } as SendableClientFrame);
  void reqId;
}

/** 演示钩子（验收截图用）：强制进入 pending 态，不发命令。 */
export function demoPending(target = 'linmo'): void {
  const s = useMapStore.getState();
  s.set({
    tokens: s.tokens.map((t) => (t.id === target ? { ...t, status: 'pending' as const } : t)),
    pendingOp: { op: 'move', target, note: '演示：拖拽已发起 · 等待裁决（mock 0.6s 后落位）' },
  });
  window.setTimeout(() => {
    const cur = useMapStore.getState();
    cur.set({
      tokens: cur.tokens.map((t) => (t.id === target
        ? { ...t, x: 300, y: 80, room: 'r_reading', status: 'settled' as const }
        : t)),
      pendingOp: null,
      log: [{ text: `落位：${target} → (300, 80)`, ts: Date.now(), actor: 'kp' }, ...cur.log].slice(0, 8),
    });
  }, 600);
}

/** 订阅 transport 下行 → 落位/拒绝回滚（调用一次，常驻）。 */
let subscribed = false;
export function ensureMapSubscription(): void {
  if (subscribed) return;
  subscribed = true;
  transport.subscribe((frame) => {
    const s = useMapStore.getState();
    if (frame.kind === 'STATE_DELTA' && frame.delta.field === 'map_op') {
      const v = frame.delta.value as { op: MapOpKind; target: string; delta: Record<string, number | string | boolean>; verdict: 'approved' | 'rejected'; note?: string };
      if (v.verdict === 'approved') {
        if (v.op === 'move') {
          s.set({
            tokens: s.tokens.map((t) => (t.id === v.target
              ? { ...t, x: Number(v.delta.x ?? t.x), y: Number(v.delta.y ?? t.y), room: String(v.delta.room ?? t.room), status: 'settled' as const }
              : t)),
            pendingOp: null,
            log: [{ text: `落位：${v.target} → (${v.delta.x}, ${v.delta.y})`, ts: Date.now(), actor: 'kp' }, ...s.log].slice(0, 8),
          });
        } else if (v.op === 'add_token') {
          s.set({
            tokens: [...s.tokens, {
              id: String(v.target), label: String(v.delta.label ?? '新'), x: Number(v.delta.x ?? 60),
              y: Number(v.delta.y ?? 60), room: String(v.delta.room ?? 'r_lobby'),
              visible: true, status: 'settled',
            }],
            pendingOp: null,
            selectedId: String(v.target),
            log: [{ text: `新增棋子：${v.target}`, ts: Date.now(), actor: 'kp' }, ...s.log].slice(0, 8),
          });
        } else if (v.op === 'set_fog') {
          s.set({
            fog: { ...s.fog, [String(v.target)]: Boolean(v.delta.fog) },
            pendingOp: null,
            log: [{ text: `迷雾：${v.target} → ${v.delta.fog ? '遮蔽' : '揭示'}`, ts: Date.now(), actor: 'kp' }, ...s.log].slice(0, 8),
          });
        }
      } else {
        // 审批拒绝 → 回滚到 settled（token 位置不动，仅清 pending 态）。
        s.set({
          tokens: s.tokens.map((t) => (t.id === v.target ? { ...t, status: 'rejected' as const } : t)),
          pendingOp: null,
          error: `审批拒绝：${v.target} 的 ${v.op} 未执行（${v.note ?? 'KP 否决'}），位置已回滚。`,
          log: [{ text: `拒绝回滚：${v.target}`, ts: Date.now(), actor: 'system' }, ...s.log].slice(0, 8),
        });
        window.setTimeout(() => {
          const cur = useMapStore.getState();
          cur.set({ tokens: cur.tokens.map((t) => (t.id === v.target ? { ...t, status: 'settled' as const } : t)) });
        }, 2500);
      }
    }
  });
}
