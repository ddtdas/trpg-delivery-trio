// transport —— 传输层单一入口（铁律：组件只经此处收发）。
//
// 运行模式由 VITE_TRPG_TRANSPORT 决定：
//   - 'mock'（默认）：mockTransport（demo 演示，无后端可跑）
//   - 'real'：RealTransport（真实 WS）
// 组件与 slice 只认本文件的 { connect, close, send, subscribe } 形状，
// 切换模式零改动组件。当前模式经 TRANSPORT_MODE 暴露，UI 打徽标。
//
// R2/t11（P0 修复）：
//   1) 连接参数支持**运行时**从 URL 查询串覆盖，构建期 env 仅作默认值 ——
//      同一份产物可在任意主机/端口/牌桌使用，无需重新构建：
//        /app/?table=t_xxx&viewer=kp1&role=kp&campaign=c_xxx&token=<token>#/kp
//      （查询串写在 hash 路由之前或之内均可）
//   2) 暴露连接状态订阅（subscribeStatus / getTransportStatus），供 UI 显示
//      真实连接态与**断连降级**提示。
//   3) 暴露 transportSnapshot()：统一 mock/real 两种实现的初始事件快照形状，
//      组件不再直接依赖 mockTransport。
import { createRealTransport, type TransportListener } from './realTransport';
import { mockTransport, type SendableClientFrame } from './mockTransport';
import type { WsStatus } from './ws';

export type MockListener = TransportListener;
export type { SendableClientFrame };
export type { WsStatus };

interface Transport {
  connect(): void;
  close(): void;
  send(frame: SendableClientFrame): void;
  subscribe(listener: MockListener): () => void;
  getStatus?(): string;
  /** 两种实现的快照形状**本就不同**：mock 返回 {state,submitted,events,proposals}，
   *  real 返回 {session,status,lastSeq}。此处放宽为 unknown，统一形状交给 transportSnapshot()。 */
  snapshot?(): unknown;
}

function env(): Record<string, string | undefined> {
  return (import.meta as unknown as { env?: Record<string, string | undefined> }).env ?? {};
}

/** 运行时覆盖：?key=value（同时支持 hash 路由内的查询串）。 */
function runtimeParam(key: string): string | undefined {
  if (typeof window === 'undefined' || !window.location) return undefined;
  try {
    const fromSearch = new URLSearchParams(window.location.search).get(key);
    if (fromSearch) return fromSearch;
    const hash = window.location.hash;
    const qi = hash.indexOf('?');
    if (qi >= 0) {
      const fromHash = new URLSearchParams(hash.slice(qi + 1)).get(key);
      if (fromHash) return fromHash;
    }
  } catch {
    /* ignore malformed query */
  }
  return undefined;
}

/** 运行时 URL 参数优先，构建期 env 兜底。 */
function pick(paramKey: string, envKey: string): string | undefined {
  return runtimeParam(paramKey) ?? env()[envKey];
}

export type TransportRole = 'kp' | 'pl' | 'spectator';

export interface ResolvedTransportParams {
  table: string;
  viewer: string;
  role: TransportRole;
  campaign: string;
  token?: string;
  baseUrl?: string;
}

/** 解析当前连接参数（供 UI/证据展示，避免"连到哪张桌"不可见）。 */
export function resolveTransportParams(): ResolvedTransportParams {
  return {
    table: pick('table', 'VITE_TRPG_TABLE') ?? 'tbl_demo',
    viewer: pick('viewer', 'VITE_TRPG_VIEWER') ?? 'kp',
    role: (pick('role', 'VITE_TRPG_ROLE') as TransportRole | undefined) ?? 'kp',
    campaign: pick('campaign', 'VITE_TRPG_CAMPAIGN') ?? 'camp-mist-port',
    token: pick('token', 'VITE_TRPG_TOKEN'),
    baseUrl: pick('ws', 'VITE_TRPG_WS_URL'),
  };
}

export function resolveMode(): 'mock' | 'real' {
  return pick('transport', 'VITE_TRPG_TRANSPORT') === 'real' ? 'real' : 'mock';
}

/* ---------------- 连接状态（R2/t11：断连降级提示的数据源） ---------------- */

const statusListeners = new Set<(s: WsStatus) => void>();
let lastStatus: WsStatus = 'idle';

function emitStatus(s: WsStatus): void {
  lastStatus = s;
  for (const fn of Array.from(statusListeners)) {
    try {
      fn(s);
    } catch {
      /* 单个订阅者异常不影响传输层 */
    }
  }
}

export function getTransportStatus(): WsStatus {
  return lastStatus;
}

/** 订阅连接状态；订阅时立即以当前状态回调一次。返回退订函数。 */
export function subscribeStatus(cb: (s: WsStatus) => void): () => void {
  statusListeners.add(cb);
  cb(lastStatus);
  return () => {
    statusListeners.delete(cb);
  };
}

/** 人类可读的连接状态文案（UI 横幅 + 降级提示共用，避免各处口径不一）。 */
export function transportStatusLabel(s: WsStatus): string {
  switch (s) {
    case 'open':
      return '已连接服务器（实时同步）';
    case 'connecting':
      return '正在连接服务器…';
    case 'reconnecting':
      return '连接中断，正在重连…（本地改动暂存，恢复后同步）';
    case 'closed':
      return '连接已关闭：改动不会同步到服务器（降级为单机演示）';
    default:
      return '尚未连接服务器';
  }
}

function buildTransport(): Transport {
  if (resolveMode() === 'real') {
    const p = resolveTransportParams();
    return createRealTransport({
      table: p.table,
      viewer: p.viewer,
      role: p.role,
      campaign: p.campaign,
      token: p.token,
      baseUrl: p.baseUrl,
      onStatus: emitStatus,
    });
  }
  return mockTransport;
}

/** 当前传输实现（构建时确定；组件层只用此单例）。 */
export const transport: Transport = buildTransport();

/** 显式标记当前走的是哪条链路（UI 横幅/证据用）。 */
export const TRANSPORT_MODE: 'mock' | 'real' = resolveMode();

/**
 * 初始事件快照 —— 统一 mock/real 形状。
 * mock 有内置剧本事件；real 无本地事件（初始为空，靠服务端帧填充）。
 */
export function transportSnapshot(): { events: string[] } {
  const snap = typeof transport.snapshot === 'function' ? transport.snapshot() : undefined;
  const events =
    snap && typeof snap === 'object' && Array.isArray((snap as { events?: unknown }).events)
      ? ((snap as { events: string[] }).events)
      : [];
  return { events };
}
